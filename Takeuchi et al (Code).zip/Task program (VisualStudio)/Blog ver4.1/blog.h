#define	ON               1
#define	OFF              0
#define	OK		 0
#define DAQmxErrChk(functionCall) if( DAQmxFailed(error=(functionCall)) ) goto Error; else

#define	BYTE unsigned char // 1byte
#define	WORD unsigned short // 2bytes
#define	DWORD unsigned long //4bytes