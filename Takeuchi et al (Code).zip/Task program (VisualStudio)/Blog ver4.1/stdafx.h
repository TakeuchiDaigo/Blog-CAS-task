#include <cstdio>
#include <fstream>
#include <time.h>
#include <conio.h>
#include <windows.h>
#include <stdlib.h>

#include <ctime>
#include <string>
#include <iostream>
#include <random>

#include "NIDAQmx.h"
#include "blog.h"
#include "tasktbl.h"