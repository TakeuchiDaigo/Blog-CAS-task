/****** module : blog.cpp
* purpose: behavior control program main routine
* author : Daigo Takeuchi
* create : 2013/10/04 ver 0.0 ******/

#include "stdafx.h"
#include "Auditory_discrimination_Rats.h"
#include "NiFpga.h"
#include "NiFpga_discriminationFPGA.h"
#include "NiFpga.c"

int main(void)
{
	int retcode;

	printf("Brain Data logging System for Rats -Ver 0.1 \n");
	printf("Copyright Daigo Takeuchi 2013. \n\n");

	retcode = blog();
}

static int blog(void)
{
	int retcode{ 1 };

	task_set = task_menu();
	retcode = block_start(task_set);

	printf("Block finished. \n\n");
	if (retcode) return retcode;
}

static int task_menu()
{
	bool  	SelectTask{ false };
	bool	exitflag{ false };
	char    TaskSelect;

	printf(" ********************\n");
	printf("    TASK SELECTION   \n");
	printf(" ********************\n\n");

	printf(" Variable-length Sequential Action Task (-v-)\n\n");

	printf(" Select Task :");

	do{
		if (_kbhit()){
			TaskSelect = _getch();
			switch (TaskSelect){
			case 'v':	task_set = TEMPID; printf(" Variable-length Sequential Action Task (-VS-)\n\n");		SelectTask = true;
				break;
			default: printf("Incorrect task selection.");
				break;
			}
		}
	} while (SelectTask == false);

	switch (task_set) {
	case QUITID: exitflag = true; break;
	case TEMPID: temp_para(); break;
	default: task_menu();
	}
	return task_set;
}

static int block_start(int task_set)
{// 1st layer
	int         error{ 0 };
	char        errBuff[2048] = { '\0' };

	//int32       lfp_read;
	//float64     lfp_data[1000];

	char		animal[32];
	char		date_time[32];
	char		blk[32];

	time_t		tm;

	int			sound_identity;
	int			required_step; // how many steps needed for action completion. 1, 2 or 3?
	int		    stim_array[1000];
	int	        step_array[1000];
	int	        step_cycle[4];

	int		    laser_switch[1000];
	//int		    laser_array[1000];

	TCHAR		*soundfile_go;

	int			performance;
	int         error_choice{ 0 };
	int			NR2A{ 0 };

	uint32_t	data_main{ 0x00000000 };
	uint32_t	trial_ready_counter{ 0x00000000 };
	uint32_t	trial_start_time{ 0x00000000 };
	uint32_t	led_on_time{ 0x00000000 };
	uint32_t	cue_start_time{ 0x00000000 };
	uint32_t	fix_break_time{ 0x00000000 };
	uint32_t	post_loop_processing_time{ 0x00000000 };
	uint32_t	delay_start_time{ 0x00000000 };
	uint32_t	delay_end_time{ 0x00000000 };

	uint32_t	choice1_time{ 0x00000000 };
	uint32_t	choice2_time{ 0x00000000 };
	uint32_t	choice3_time{ 0x00000000 };

	uint32_t	emv_on_time1{ 0x00000000 };
	uint32_t	emv_on_time2{ 0x00000000 };
	uint32_t	emv_on_time3{ 0x00000000 };
	uint32_t	error_feedback_on_time{ 0x00000000 };
	uint32_t	NR2A_feedback_on_time{ 0x00000000 };
	uint32_t	iti_start_time{ 0x00000000 };

	uint32_t	data_middle_falling{ 0x00000000 };
	uint32_t	data_left_falling{ 0x00000000 };
	uint32_t	data_right_falling{ 0x00000000 };

	uint32_t	counter_value_middle_falling{ 0x00000000 };
	uint32_t	counter_value_left_falling{ 0x00000000 };
	uint32_t	counter_value_right_falling{ 0x00000000 };

	bool		Exitflag{ false };
	bool		TrialExitflag{ false };
	bool		FixationExitFlag{ false };
	bool		MiddlePortExitflag{ false };
	bool		NR2A_WindowExitflag{ false };

	bool		First_Went_to_Left_Flag{ false };
	bool		First_Went_to_Right_Flag{ false };
	bool        RepechageExitflag{ false };
	bool		Serial_Response_Completed_Flag{ false };

	bool		fixation_break{ false };
	//bool		middle_portin{ false };

	int			performance_choice1;
	int			performance_choice2;
	int			performance_choice3;

	bool		error_correction_trial{ false };

	uint32_t		trial{};

	uint32_t		trial_gl_l{};
	uint32_t		trial_gl_r{};
	uint32_t		trial_gr_r{};
	uint32_t		trial_gr_l{};

	uint32_t		trial_glr_lr{};
	uint32_t		trial_glr_lc{};
	uint32_t		trial_glr_r{};
	uint32_t		trial_grl_rl{};
	uint32_t		trial_grl_rc{};
	uint32_t		trial_grl_l{};

	uint32_t		trial_glrl_lrl{};
	uint32_t		trial_glrl_lrc{};
	uint32_t		trial_glrl_lc{};
	uint32_t		trial_glrl_r{};
	uint32_t		trial_grlr_rlr{};
	uint32_t		trial_grlr_rlc{};
	uint32_t		trial_grlr_rc{};
	uint32_t		trial_grlr_l{};

	uint32_t		response_time_choice1{ 0x00000000 };
	uint32_t		response_time_choice2{ 0x00000000 };
	uint32_t		response_time_choice3{ 0x00000000 };

	/// Task Parameters ///

	int			Blockwise_switch{ 0 }; // 0: random 1: block for all sequence 2: 1: block for specified sequence
	int			Block_length_cue{ 500 };
	int         First_block_trial_type{ 0 };
	int			Block_sequence[6];

	int			bias_tone{ 0 }; // weighted presentation of tones
	int			bias_ratio{ 3 }; // weighted presentation of tones
	int			repeat_limit{ 5 }; // max no. of repeat of identical tone

	int			Error_feedback_buzzer_NR2A{ 1 }; // 0: error buzzer off 1: error buzzer on
	uint32_t	window_NR2A = { 3000 };

	int			Blockwise_variable_step_switch{ 1 }; // 0: fixed steps  1: variable-step CAS task
	int			fixed_step = 2;
				step_cycle[0] = 2;
				step_cycle[1] = 1;
				step_cycle[2] = 2; 
				step_cycle[3] = 1;

	int			Block_length_step{ 55 };

	int			Reject_center_leverin_switch{ 0 }; // Abort trial when animal presses center lever during 2nd or 3rd response.  

	int			Catch_trial_switch = { 0 }; // Add catch trial at the start of the experiment.
	int			num_catch_trial = { 20 };
	uint32_t	catch_trial_interval = { 2000 };

	uint32_t	wait_cue_duration = { 10 }; /* msec*/
	uint32_t	cue_stimulus_duration = { 100 }; /* msec*/

	int			Fixation_switch{ 0 };
	uint32_t	fixation_duration = cue_stimulus_duration; /* msec*/
	//uint32_t	fixation_duration = { 1000 }; /* msec*/

	uint32_t    tone_high{ 8 };

	uint32_t	delay_period = { 10 }; /* msec*/
	uint32_t	delay_period_corrected;  

	int			delay_period_increment_switch{ 0 };
	uint32_t	delay_period_increment_step{ 1 }; /* msec*/

	int			Choice_guide_LED{ 0 };
	int			Choice_guide_LED_trial{ 10 }; // if Choice_guide_LED{ 1 };  
  
	int			Choice_guide{ 0 }; // 0: both L & R levers are presented; 1: incorrect lever not presented; 2: all L/M/R levers are always kept presented. 
	int			Choice_guide_trial{ 60 }; // if Choice_guide{ 1 };

	int         LED_off_timing{ 0 }; // 0: on animal's 1st response; 1: on animal's completion of response sequence

	int			random_delay_reward_switch{ 1 }; // need an new rndm function for randomized delay
	uint32_t	delay_reward_range = { 100 }; /* randomized additional delay msec*/
	uint32_t	delay_reward = { 50 }; /* minimum delay duration (msec) */
	uint32_t	random_delay_reward{ 0 };

	int			Reward_delivery_switch{ 1 }; // 0: lump-sum delivery of reward; 1: multipe-step deliveries of reward. 
	uint32_t	EMV_open_duration_interim = { 120 }; /* msec*/  // for help reward
	uint32_t	EMV_open_duration_final = { 300 }; // for the final reward

	/*
	uint32_t	iti = { 2700 };
	uint32_t	iti_correct = { 2700 };
	uint32_t    iti_error = { 4000 };
	*/

	// /*
	uint32_t	iti = { 500 };
	uint32_t	iti_correct = { 2000 };
	uint32_t    iti_error = { 3500 };
	uint32_t    iti_error_NR2A = { 3500 };
	// */

	int			Tone_on_until_choice{ 1 }; // 0: Fixed duration of sound 1: tone kept on until choice

	int			Error_feedback_buzzer{ 1 }; // 0: error buzzer off 1: error buzzer on

	int			Tone_feedback{ 0 }; // 0: no tone 1: tone on when lever-in
	int			Error_correction{ 0 }; // 0: no follow-up trial 1: follow-up trial 2: repeat until correct response

	int			Repechage_choice2_switch{ 0 }; // 0: no help 1: help (+) Ref. Duan et al. 2015 Neuron SOM
	int			Repechage_choice3_switch{ 0 }; // 0: no help 1: help (+) Ref. Duan et al. 2015 Neuron SOM
	uint32_t	delay_repechage{ 100 }; /* msec*/

	int			laser_experiment{ 0 };
	int			laser_on_trial_proportion{ 1 }; // if N, the laser on likelihood is 1 in N.
	int			laser_repeat_limit{ 55 };
	int			laser_on_trial_length{ 55 }; // num of trials with laser on from the 1st trial of the new block (block#2, #3,,,)
	int			laser_delivery_epoch{ 0 }; // if 0, starting at the onset of cue tone. if 1, starting at the entry of side port (1st choice). if 2, starting at the correct 2nd choice (i.e. entry of side port). if 3, starting at the entry of error center lever-in in 2nd choice of step=2 block. if 4, starting at the entry of side port (non-rewarded 2nd action, NR2A) in step=1 block.
	//uint32_t 	delay_laser{ 500 };  

	/// Task Parameters END///

	time(&tm);
	std::string sCurrentTime = FormatTime(tm);
	cout << sCurrentTime << endl;

	printf("Input Animal ID.\n");
	scanf("%s", animal);
	printf("Animal ID: %s \n\n", animal);

	// /*
	printf("Input Date-Time.\n");
	scanf("%s", date_time);
	printf("Date-Time: %s \n\n", date_time);

	printf("Input Block No.\n");
	scanf("%s", blk);

	printf("Block: %s \n\n", blk);
	//  */

	// cout 

	///// Make Sound Sequence ////////
	int     tmp;
	int		tmp2{ 0 };

	for (int i{ 0 }; i <= 1; i++){
		Block_sequence[i] = i % 2;
	} // ordering of blocks

	///// Make Variable steps Sequence (blockwise switch of required number of lever-press actions for trial completion) ////////

	switch (Blockwise_variable_step_switch){

	case 0:
		for (int i{ 0 }; i <= 999; i++)
		{
			step_array[i] = fixed_step;
		}
		break;

	case 1:
		for (int i{ 0 }; i <= 999; i++)
		{

			if ((i / (Block_length_step)) % 4 == 0){
				step_array[i] = step_cycle[0];
			}
			else if ((i / (Block_length_step)) % 4 == 1){
				step_array[i] = step_cycle[1];
			}
			else if ((i / (Block_length_step)) % 4 == 2){
				step_array[i] = step_cycle[2];
			}
			else if ((i / (Block_length_step)) % 4 == 3){
				step_array[i] = step_cycle[3];
			}

		}

		break;
	}

	///// Make Pseudo-Randomized Sound Sequence ////////
	switch (Blockwise_switch){
	case 0:

		for (int i{ 0 }; i <= 999; i++)
		{
			tmp = rnd() % (bias_ratio + 1);

			if (tmp == 0){
				stim_array[i] = (bias_tone + 1) % 2;
			}
			if (tmp > 0){
				stim_array[i] = bias_tone % 2;
			}
		}

		if (bias_ratio < repeat_limit){
			for (int i{ 0 }; i <= (999 - repeat_limit); i++)
			{

				if (repeat_limit == 3){
					tmp2 = stim_array[i] + stim_array[i + 1] + stim_array[i + 2];
				}
				if (repeat_limit == 4){
					tmp2 = stim_array[i] + stim_array[i + 1] + stim_array[i + 2] + stim_array[i + 3];
				}
				if (repeat_limit == 5){
					tmp2 = stim_array[i] + stim_array[i + 1] + stim_array[i + 2] + stim_array[i + 3] + stim_array[i + 4];
				}
				if (repeat_limit == 6){
					tmp2 = stim_array[i] + stim_array[i + 1] + stim_array[i + 2] + stim_array[i + 3] + stim_array[i + 4] + stim_array[i + 5];
				}

				if (tmp2 == 0){
					stim_array[i + repeat_limit] = 1; // prohibit five successive 0s.
				}
				if (tmp2 == repeat_limit){
					stim_array[i + repeat_limit] = 0; // prohibit five successive 1s.
				}
				tmp2 = 0;
			}
		}
		break;

	case 1:
		for (int i{ 0 }; i <= 999; i++)
		{
			if ((i / Block_length_cue) % 2 == 0) {
				if (First_block_trial_type == 0) {
					stim_array[i] = Block_sequence[0];
				}
				else if (First_block_trial_type == 1) {
					stim_array[i] = Block_sequence[1];
				}
			}
			else if ((i / Block_length_cue) % 2 == 1) {
				if (First_block_trial_type == 0) {
					stim_array[i] = Block_sequence[1];
				}
				else if (First_block_trial_type == 1) {
					stim_array[i] = Block_sequence[0];
				}
			}
		}

		break;

	case 2:
		for (int i{ 0 }; i <= 999; i++)
		{
			stim_array[i] = Block_sequence[0];
		}
		break;
	}
	////////////////////////////////

	///// Make Laser Sequence ////////

	if (laser_experiment == 1){

		int     tmp4;
		int     tmp5;

		for (int i{ 0 }; i <= 999; i++)
		{
			//tmp4 = rnd() % laser_on_trial_proportion;

			//laser_switch[i] = 1;

			// /*
			if ((i>(Block_length_step - 1))&((i%Block_length_step) < laser_on_trial_length)){
				laser_switch[i] = 1;
			}
			else
				laser_switch[i] = 0;

			// */

			/*
			if (tmp4 == 0){
			laser_switch[i] = 1;
			}
			if (tmp4 > 0){
			laser_switch[i] = 0;
			}
			tmp4 = 0;
			*/
		}

		/*
		for (int i{ 0 }; i <= (999 - laser_repeat_limit); i++)
		{

		if (laser_on_trial_proportion == 3){
		tmp5 = stim_sequence[i] * stim_sequence[i + 1] * stim_sequence[i + 2];
		}
		if (laser_on_trial_proportion == 4){
		tmp5 = stim_sequence[i] * stim_sequence[i + 1] * stim_sequence[i + 2] * stim_sequence[i + 3];
		}
		if (laser_on_trial_proportion == 5){
		tmp5 = stim_sequence[i] + stim_sequence[i + 1] * stim_sequence[i + 2] * stim_sequence[i + 3] * stim_sequence[i + 4];
		}
		if (laser_on_trial_proportion == 6){
		tmp5 = stim_sequence[i] + stim_sequence[i + 1] * stim_sequence[i + 2] * stim_sequence[i + 3] * stim_sequence[i + 4];
		}

		if (tmp5 == 1){
		stim_sequence[i + repeat_limit] = 0; // prohibit successive 1s.
		}

		tmp5 = 0;
		}
		*/

	}

	////////////////////////////////

	std::ofstream log;

	std::string filename0("Sound_");
	filename0 += animal;
	filename0 += "_";
	filename0 += date_time;
	filename0 += "_BLK";
	filename0 += blk;
	filename0 += ".txt";

	log.open(filename0.c_str());
	for (int i{ 0 }; i <= 999; i++){
		log << step_array[i] << endl;
	}
	log.close();

	std::string filename1("Sound_");
	filename1 += animal;
	filename1 += "_";
	filename1 += date_time;
	filename1 += "_BLK";
	filename1 += blk;
	filename1 += ".txt";

	log.open(filename1.c_str());
	for (int i{ 0 }; i <= 999; i++){
		log << stim_array[i] << endl;
	}
	log.close();

	if (laser_experiment == 1){
		std::string filename2("Laser_");
		filename2 += animal;
		filename2 += "_";
		filename2 += date_time;
		filename2 += "_BLK";
		filename2 += blk;
		filename2 += ".txt";

		log.open(filename2.c_str());
		for (int i{ 0 }; i <= 999; i++){
			log << laser_switch[i] << endl;
		}
		log.close();
	}

	std::string filename3("Log_");
	filename3 += animal;
	filename3 += "_";
	filename3 += date_time;
	filename3 += "_BLK";
	filename3 += blk;
	filename3 += ".txt";

	log.open(filename3.c_str());

	log << sCurrentTime << endl;
	log << "Animal: " << animal << endl;
	log << "Block: " << blk << endl;

	log << "Catch_trial_switch: " << Catch_trial_switch << endl;
	log << "num_catch_trial: " << num_catch_trial << endl;
	log << "catch_trial_interval: " << catch_trial_interval << endl;

	//log << "Blockwise_switch: " << Blockwise_switch << endl;
	//log << "Block_length_cue: " << Block_length_cue << endl;
	log << "repeat_limit: " << repeat_limit << endl;
	log << "bias_tone: " << bias_tone << endl;
	log << "bias_ratio: " << bias_ratio << endl;

	log << "Blockwise_variable_step_switch: " << Blockwise_variable_step_switch << endl;
	log << "Block_length_step: " << Block_length_step << endl;
	switch (Blockwise_variable_step_switch){
	case 0:
		log << "step_cycle[0]: " << fixed_step << endl;
		log << "step_cycle[1]: " << fixed_step << endl;
		log << "step_cycle[2]: " << fixed_step << endl;
		log << "step_cycle[3]: " << fixed_step << endl;
		break;
	case 1:
		log << "step_cycle[0]: " << step_cycle[0] << endl;
		log << "step_cycle[1]: " << step_cycle[1] << endl;
		log << "step_cycle[2]: " << step_cycle[2] << endl;
		log << "step_cycle[3]: " << step_cycle[3] << endl;
		break;
	}

	log << "Reject_center_leverin_switch: " << Reject_center_leverin_switch << endl;
	//log << "Choice_guide: " << Choice_guide << endl;
	//log << "Choice_guide_trial: " << Choice_guide_trial << endl;
	log << "Choice_guide_LED: " << Choice_guide_LED << endl;
	log << "Choice_guide_LED_trial: " << Choice_guide_LED_trial << endl;

	log << "LED_off_timing: " << LED_off_timing << endl;

	log << "Error_feedback_buzzer_NR2A: " << Error_feedback_buzzer_NR2A << endl;
	log << "window_NR2A: " << window_NR2A << endl;
	//log << "Tone_feedback: " << Tone_feedback << endl;
	log << "Error_correction: " << Error_correction << endl;
	//log << "Repechage_switch: " << Repechage_switch << endl;

	log << "Precue: " << wait_cue_duration << endl;
	log << "cue_stimulus_duration: " << cue_stimulus_duration << endl;

	//log << "Fix_Switch: " << Fixation_switch << endl;
	//log << "Fix_Duration: " << fixation_duration << endl;
	log << "delay_period: " << delay_period << endl;

	log << "random_delay_reward_switch: " << random_delay_reward_switch << endl;
	log << "delay_reward_range: " << delay_reward_range << endl;
	log << "delay_reward: " << delay_reward << endl;

	//log << "delay_repechage: " << delay_repechage << endl;
	log << "Reward_delivery_switch: " << Reward_delivery_switch << endl;
	log << "EMV_open_duration_interim: " << EMV_open_duration_interim << endl;
	log << "EMV_open_duration_final: " << EMV_open_duration_final << endl;

	log << "iti_correct: " << iti_correct << endl;
	log << "iti_error: " << iti_error << endl;

	log << "laser_experiment: " << laser_experiment << endl;
	//log << "delay_laser: " << delay_laser << endl;
	log << "laser_on_trial_proportion: " << laser_on_trial_proportion << endl;
	log << "laser_repeat_limit: " << laser_repeat_limit << endl;
	log << "laser_on_trial_length: " << laser_on_trial_length << endl;
	log << "laser_delivery_epoch: " << laser_delivery_epoch << endl;

	printf("Initializing...\n");
	NiFpga_Status status = NiFpga_Initialize();
	if (NiFpga_IsNotError(status))
	{// 2nd layer
		NiFpga_Session session;

		/* opens a session, downloads the bitstream, and runs the FPGA */
		printf("\r\rOpening a session...\n");
		NiFpga_MergeStatus(&status, NiFpga_Open(NiFpga_discriminationFPGA_Bitfile, NiFpga_discriminationFPGA_Signature, "RIO0", NiFpga_OpenAttribute_NoRun, &session));
		//NiFpga_MergeStatus(&status, NiFpga_Open(NiFpga_discriminationfpga_Bitfile, NiFpga_discriminationfpga_Signature, "RIO0", 0, &session));

		NiFpga_MergeStatus(&status, NiFpga_WriteBool(session, NiFpga_discriminationFPGA_ControlBool_Enable_CLK, ON));
		NiFpga_MergeStatus(&status, NiFpga_WriteBool(session, NiFpga_discriminationFPGA_ControlBool_Enable_EMV, ON));
		//NiFpga_MergeStatus(&status, NiFpga_WriteBool(session, NiFpga_discriminationFPGA_ControlBool_Enable_Lever_Left, ON));
		//NiFpga_MergeStatus(&status, NiFpga_WriteBool(session, NiFpga_discriminationFPGA_ControlBool_Enable_Lever_Middle, ON));
		//NiFpga_MergeStatus(&status, NiFpga_WriteBool(session, NiFpga_discriminationFPGA_ControlBool_Enable_Lever_Right, ON));
		NiFpga_MergeStatus(&status, NiFpga_WriteBool(session, NiFpga_discriminationFPGA_ControlBool_Enable_LED_Left, ON));
		NiFpga_MergeStatus(&status, NiFpga_WriteBool(session, NiFpga_discriminationFPGA_ControlBool_Enable_LED_Middle, ON));
		NiFpga_MergeStatus(&status, NiFpga_WriteBool(session, NiFpga_discriminationFPGA_ControlBool_Enable_LED_Right, ON));
		NiFpga_MergeStatus(&status, NiFpga_WriteBool(session, NiFpga_discriminationFPGA_ControlBool_Enable_Eventflag, ON));
		NiFpga_MergeStatus(&status, NiFpga_WriteBool(session, NiFpga_discriminationFPGA_ControlBool_Enable_Laser, ON));

		NiFpga_MergeStatus(&status, NiFpga_WriteBool(session, NiFpga_discriminationFPGA_ControlBool_EMV, OFF));
		NiFpga_MergeStatus(&status, NiFpga_WriteBool(session, NiFpga_discriminationFPGA_ControlBool_Catch_Trial, OFF));
		//NiFpga_MergeStatus(&status, NiFpga_WriteBool(session, NiFpga_discriminationFPGA_ControlBool_Lever_Left, OFF));
		//NiFpga_MergeStatus(&status, NiFpga_WriteBool(session, NiFpga_discriminationFPGA_ControlBool_Lever_Middle, OFF));
		//NiFpga_MergeStatus(&status, NiFpga_WriteBool(session, NiFpga_discriminationFPGA_ControlBool_Lever_Right, OFF));
		NiFpga_MergeStatus(&status, NiFpga_WriteBool(session, NiFpga_discriminationFPGA_ControlBool_LED_Left, false));
		NiFpga_MergeStatus(&status, NiFpga_WriteBool(session, NiFpga_discriminationFPGA_ControlBool_LED_Middle, false));
		NiFpga_MergeStatus(&status, NiFpga_WriteBool(session, NiFpga_discriminationFPGA_ControlBool_LED_Right, false));
		NiFpga_MergeStatus(&status, NiFpga_WriteBool(session, NiFpga_discriminationFPGA_ControlBool_Counter_middle_ON, OFF));
		NiFpga_MergeStatus(&status, NiFpga_WriteBool(session, NiFpga_discriminationFPGA_ControlBool_Counter_middle_falling_ON, OFF));
		NiFpga_MergeStatus(&status, NiFpga_WriteBool(session, NiFpga_discriminationFPGA_ControlBool_EF_Flag, OFF));
		NiFpga_MergeStatus(&status, NiFpga_WriteBool(session, NiFpga_discriminationFPGA_ControlBool_Laser, OFF));

		NiFpga_MergeStatus(&status, NiFpga_WriteU32(session, NiFpga_discriminationFPGA_ControlU32_delay_left, 0));
		NiFpga_MergeStatus(&status, NiFpga_WriteU32(session, NiFpga_discriminationFPGA_ControlU32_delay_middle, 0));
		NiFpga_MergeStatus(&status, NiFpga_WriteU32(session, NiFpga_discriminationFPGA_ControlU32_delay_right, 0));
		//NiFpga_MergeStatus(&status, NiFpga_WriteU32(session, NiFpga_discriminationFPGA_ControlU32_delay_left, delay_period));
		//NiFpga_MergeStatus(&status, NiFpga_WriteU32(session, NiFpga_discriminationFPGA_ControlU32_delay_middle, delay_period));
		//NiFpga_MergeStatus(&status, NiFpga_WriteU32(session, NiFpga_discriminationFPGA_ControlU32_delay_right, delay_period));

		NiFpga_MergeStatus(&status, NiFpga_WriteU32(session, NiFpga_discriminationFPGA_ControlU32_delay_reward, delay_reward));
		NiFpga_MergeStatus(&status, NiFpga_WriteU32(session, NiFpga_discriminationFPGA_ControlU32_EMV_open_duration_catch, EMV_open_duration_interim));
		NiFpga_MergeStatus(&status, NiFpga_WriteU32(session, NiFpga_discriminationFPGA_ControlU32_EMV_open_duration_catch, EMV_open_duration_interim));
		NiFpga_MergeStatus(&status, NiFpga_WriteU32(session, NiFpga_discriminationFPGA_ControlU32_EMV_open_duration, EMV_open_duration_final));
		//NiFpga_MergeStatus(&status, NiFpga_WriteU32(session, NiFpga_discriminationFPGA_ControlU32_EMV_open_duration, EMV_open_duration));
		//NiFpga_MergeStatus(&status, NiFpga_WriteU32(session, NiFpga_discriminationFPGA_ControlU32_EMV_open_duration_catch, EMV_open_duration_catch));

		/* run the FPGA application */
		printf("\r\rRun FPGA...\n");
		printf("\n\r ------------------------------\n\n");
		NiFpga_MergeStatus(&status, NiFpga_Run(session, 0));

		//NiFpga_MergeStatus(&status, NiFpga_ReadU32(session, NiFpga_discriminationFPGA_IndicatorU32_data_middle, &data_middle));
		//counter_value_middle = data_middle;

		NiFpga_MergeStatus(&status, NiFpga_ReadU32(session, NiFpga_discriminationFPGA_IndicatorU32_data_middle_falling, &data_middle_falling));
		counter_value_middle_falling = data_middle_falling;

		//NiFpga_MergeStatus(&status, NiFpga_ReadU32(session, NiFpga_discriminationFPGA_IndicatorU32_data_left, &data_left));
		//counter_value_left = data_left;

		NiFpga_MergeStatus(&status, NiFpga_ReadU32(session, NiFpga_discriminationFPGA_IndicatorU32_data_left_falling, &data_left_falling));
		counter_value_left_falling = data_left_falling;

		//NiFpga_MergeStatus(&status, NiFpga_ReadU32(session, NiFpga_discriminationFPGA_IndicatorU32_data_right, &data_right));
		//counter_value_right = data_right;

		NiFpga_MergeStatus(&status, NiFpga_ReadU32(session, NiFpga_discriminationFPGA_IndicatorU32_data_right_falling, &data_right_falling));
		counter_value_right_falling = data_right_falling;


		/* Block start*/
		//NiFpga_MergeStatus(&status, NiFpga_WriteBool(session, NiFpga_discriminationFPGA_ControlBool_EF_Flag, ON));//timing of block start

		NiFpga_MergeStatus(&status, NiFpga_WriteBool(session, NiFpga_discriminationFPGA_ControlBool_LED_Left, false));
		NiFpga_MergeStatus(&status, NiFpga_WriteBool(session, NiFpga_discriminationFPGA_ControlBool_LED_Middle, false));
		NiFpga_MergeStatus(&status, NiFpga_WriteBool(session, NiFpga_discriminationFPGA_ControlBool_LED_Right, false));

		/// Catch trial Start /////
		if (Catch_trial_switch == 1){
			NiFpga_MergeStatus(&status, NiFpga_WriteBool(session, NiFpga_discriminationFPGA_ControlBool_Catch_Trial, ON));
			Sleep(5000);

			for (int i{ 1 }; i <= num_catch_trial; i++)
			{
				NiFpga_MergeStatus(&status, NiFpga_WriteBool(session, NiFpga_discriminationFPGA_ControlBool_EMV, ON));
				Sleep(catch_trial_interval);
				printf("Catch trial: %d \n\n", i);

				if (i == num_catch_trial){
					printf("------------------------\n\n");
				}
			}

			NiFpga_MergeStatus(&status, NiFpga_WriteBool(session, NiFpga_discriminationFPGA_ControlBool_Catch_Trial, OFF));
		}
		/// Catch trial End /////

		NiFpga_MergeStatus(&status, NiFpga_WriteBool(session, NiFpga_discriminationFPGA_ControlBool_LED_Middle, true)); // initial condition
		//NiFpga_MergeStatus(&status, NiFpga_WriteBool(session, NiFpga_discriminationFPGA_ControlBool_Lever_Middle, ON));

		do{// 3rd layer

			do{// 4th layer
				NiFpga_MergeStatus(&status, NiFpga_ReadU32(session, NiFpga_discriminationFPGA_IndicatorU32_data_main, &data_main));

				printf("\r data_main =      %d", data_main);

				if ((data_main - iti_start_time) <= iti * 1000){
					NiFpga_MergeStatus(&status, NiFpga_ReadU32(session, NiFpga_discriminationFPGA_IndicatorU32_data_middle_falling, &data_middle_falling));
					counter_value_middle_falling = data_middle_falling;
				}

				if ((data_main - iti_start_time) > iti * 1000){// 5th layer

					++trial_ready_counter; // added on 20180316
					//printf("\r trial_ready_counter =      %d", trial_ready_counter);
					if (trial_ready_counter == 1) {
						NiFpga_MergeStatus(&status, NiFpga_WriteBool(session, NiFpga_discriminationFPGA_ControlBool_LED_Middle, true));
						NiFpga_MergeStatus(&status, NiFpga_ReadU32(session, NiFpga_discriminationFPGA_IndicatorU32_data_main, &data_main));
						led_on_time = data_main; // moved here on 20180315
					}

					NiFpga_MergeStatus(&status, NiFpga_WriteBool(session, NiFpga_discriminationFPGA_ControlBool_Counter_middle_ON, ON));
					NiFpga_MergeStatus(&status, NiFpga_WriteBool(session, NiFpga_discriminationFPGA_ControlBool_Counter_middle_falling_ON, ON));

					NiFpga_MergeStatus(&status, NiFpga_ReadU32(session, NiFpga_discriminationFPGA_IndicatorU32_data_middle_falling, &data_middle_falling));

					if (data_middle_falling > counter_value_middle_falling){
						printf("\n\r data_middle_falling = %d\n", data_middle_falling);

						NiFpga_MergeStatus(&status, NiFpga_ReadU32(session, NiFpga_discriminationFPGA_IndicatorU32_data_main, &data_main));
						trial_start_time = data_main;

						NiFpga_MergeStatus(&status, NiFpga_WriteBool(session, NiFpga_discriminationFPGA_ControlBool_EF_Flag, ON)); //timing of animal's center lever in

						iti_start_time = 0x00000000;

						if (trial > 0){
							if (Error_correction > 0){
								if (error_choice == OFF){
									error_correction_trial = false;
									sound_identity = stim_array[trial];
								}
								else{
									error_correction_trial = true;
									sound_identity = sound_identity;
								}
							}

							else {
								error_correction_trial = false;
								sound_identity = stim_array[trial];
								//sound_identity = 2;
							}
						}

						else{
							error_correction_trial = false;
							sound_identity = stim_array[0];
						}

						required_step = step_array[trial];

						printf("\n\r Cue: %d\n", sound_identity);
						printf("\n\r #Step: %d\n", required_step);

						switch (sound_identity)
						{
						case 0:
							soundfile_go = TEXT("5khz_300ms_025.wav"); //FIFO 
							//soundfile_go = TEXT("5khz_300ms_015.wav"); //FIFO 
							break;

						case 1:
							if (tone_high == 8){
								soundfile_go = TEXT("8khz_300ms_025.wav"); //FIFO 
							}
							else if (tone_high == 12){
								soundfile_go = TEXT("12khz_300ms_030.wav"); //FIFO 
							}
							break;
						}

						Sleep(wait_cue_duration); // Pre-cue
						//NiFpga_MergeStatus(&status, NiFpga_WriteBool(session, NiFpga_discriminationFPGA_ControlBool_EF_Flag, ON)); //timing of cue tone ON 

						NiFpga_MergeStatus(&status, NiFpga_ReadU32(session, NiFpga_discriminationFPGA_IndicatorU32_data_main, &data_main));
						cue_start_time = data_main;

						switch (Tone_on_until_choice){
						case 0:
							go_signal_on_fixed(soundfile_go);
							break;
						case 1:
							go_signal_on_cont(soundfile_go);
							break;
						}

						if (laser_switch[trial] == 1){
							if (laser_delivery_epoch == 0){
								NiFpga_MergeStatus(&status, NiFpga_WriteBool(session, NiFpga_discriminationFPGA_ControlBool_Laser, ON)); //20180815
							}
						}

						Sleep(cue_stimulus_duration); // cue

						//NiFpga_MergeStatus(&status, NiFpga_WriteBool(session, NiFpga_discriminationFPGA_ControlBool_LED_Middle, false));

						NiFpga_MergeStatus(&status, NiFpga_ReadU32(session, NiFpga_discriminationFPGA_IndicatorU32_data_main, &data_main));
						delay_start_time = data_main;

						if (fixation_break == true){// 7th layer
							fixation_break = false;
						}

						else{// 7th layer -fixation break or no.

							///// Laser Module Under Construction ////////////////////////////
							/*
							NiFpga_MergeStatus(&status, NiFpga_WriteBool(session, NiFpga_discriminationFPGA_ControlBool_Laser, OFF));
							if (laser_experiment == 1){
							Sleep(delay_laser);

							if (laser_array[trial] == 1){
							NiFpga_MergeStatus(&status, NiFpga_WriteBool(session, NiFpga_discriminationFPGA_ControlBool_Laser, ON));
							}

							if (laser_array[trial] == 0){
							NiFpga_MergeStatus(&status, NiFpga_WriteBool(session, NiFpga_discriminationFPGA_ControlBool_Laser, OFF));
							}
							}
							*/
							///// Laser Module Under Construction ////////////////////////////

							//NiFpga_MergeStatus(&status, NiFpga_WriteBool(session, NiFpga_discriminationFPGA_ControlBool_EF_Flag, ON)); //timing of delay start

							/*
							NiFpga_MergeStatus(&status, NiFpga_ReadU32(session, NiFpga_discriminationFPGA_IndicatorU32_data_main, &data_main));
							post_loop_processing_time = data_main;

							switch (delay_period_increment_switch){
							case 0:
							delay_period_corrected = delay_period - (post_loop_processing_time - cue_start_time) / 1000 + cue_stimulus_duration; // Note that 'cue_start_time' is read not after the tone presentation completes but immediately after the tone presentation starts.
							printf("\n\n\r post_loop_processing_time - cue_start_time = %d msec\n", (post_loop_processing_time - cue_start_time) / 1000);
							break;
							case 1:
							delay_period_corrected = delay_period + delay_period_increment_step*trial - (post_loop_processing_time - cue_start_time) / 1000 + cue_stimulus_duration; // Note that 'cue_start_time' is read not after the tone presentation completes but immediately after the tone presentation starts.
							printf("\n\n\r post_loop_processing_time - cue_start_time = %d msec\n", (post_loop_processing_time - cue_start_time) / 1000);
							break;
							}

							Sleep(delay_period_corrected);
							printf("\n\n\r delay_period_corrected = %d msec\n", delay_period_corrected);
							*/

							NiFpga_MergeStatus(&status, NiFpga_ReadU32(session, NiFpga_discriminationFPGA_IndicatorU32_data_main, &data_main));
							delay_end_time = data_main;

							//NiFpga_MergeStatus(&status, NiFpga_WriteBool(session, NiFpga_discriminationFPGA_ControlBool_LED_Middle, false));

							NiFpga_MergeStatus(&status, NiFpga_ReadU32(session, NiFpga_discriminationFPGA_IndicatorU32_data_left_falling, &data_left_falling));
							counter_value_left_falling = data_left_falling;

							NiFpga_MergeStatus(&status, NiFpga_ReadU32(session, NiFpga_discriminationFPGA_IndicatorU32_data_right_falling, &data_right_falling));
							counter_value_right_falling = data_right_falling;

							do{ /// Start of Response  // 8th layer
								//NiFpga_MergeStatus(&status, NiFpga_ReadU32(session, NiFpga_discriminationFPGA_IndicatorU32_data_middle, &data_middle));
								NiFpga_MergeStatus(&status, NiFpga_ReadU32(session, NiFpga_discriminationFPGA_IndicatorU32_data_left_falling, &data_left_falling));
								NiFpga_MergeStatus(&status, NiFpga_ReadU32(session, NiFpga_discriminationFPGA_IndicatorU32_data_right_falling, &data_right_falling));

								/// Start of First went to Left Port ///
								if (data_left_falling > counter_value_left_falling){ // 9th layer

									NiFpga_MergeStatus(&status, NiFpga_ReadU32(session, NiFpga_discriminationFPGA_IndicatorU32_data_main, &data_main));
									choice1_time = data_main;
									//response_time_choice1 = choice1_time - cue_start_time;

									//NiFpga_MergeStatus(&status, NiFpga_WriteBool(session, NiFpga_discriminationFPGA_ControlBool_EF_Flag, ON)); //timing of animal's left lever in 
									
									if (laser_switch[trial] == 1){
										if (laser_delivery_epoch == 1){
											NiFpga_MergeStatus(&status, NiFpga_WriteBool(session, NiFpga_discriminationFPGA_ControlBool_Laser, ON)); //2018015
										}
									}

									PlaySound(NULL, NULL, SND_ASYNC); //2016-01-06 added to stop tone in "Tone On Until Choice" mode


									switch (sound_identity)
									{ // 10th layer - which cue? 0 or 1?

									case 0:

										NiFpga_MergeStatus(&status, NiFpga_ReadU32(session, NiFpga_discriminationFPGA_IndicatorU32_data_main, &data_main));
										//choice_sound1_time = data_main;

										counter_value_middle_falling = data_middle_falling;
										counter_value_left_falling = data_left_falling;
										counter_value_right_falling = data_right_falling;

										NiFpga_MergeStatus(&status, NiFpga_WriteBool(session, NiFpga_discriminationFPGA_ControlBool_LED_Left, false));
										//Sleep(lever_retract_delay1);

										performance_choice1 = 1;

										switch (required_step)
										{
										case 1:
											NiFpga_MergeStatus(&status, NiFpga_ReadU32(session, NiFpga_discriminationFPGA_IndicatorU32_data_main, &data_main));
											choice1_time = data_main;

											NiFpga_MergeStatus(&status, NiFpga_WriteBool(session, NiFpga_discriminationFPGA_ControlBool_LED_Middle, false));
											NiFpga_MergeStatus(&status, NiFpga_WriteBool(session, NiFpga_discriminationFPGA_ControlBool_LED_Right, false));

											NiFpga_MergeStatus(&status, NiFpga_WriteBool(session, NiFpga_discriminationFPGA_ControlBool_Catch_Trial, OFF));

											if (random_delay_reward_switch == 1){
												random_delay_reward = rnd() % delay_reward_range;
												Sleep(random_delay_reward);
											}

											NiFpga_MergeStatus(&status, NiFpga_ReadU32(session, NiFpga_discriminationFPGA_IndicatorU32_data_main, &data_main));
											emv_on_time1 = data_main;
											NiFpga_MergeStatus(&status, NiFpga_WriteBool(session, NiFpga_discriminationFPGA_ControlBool_EMV, ON));

											performance_choice1 = 1;
											performance = 1;
											error_choice = OFF;

											iti = iti_correct;

											++trial_gl_l;

											// 2020-02-20 Add error feedback buzzer for NR2A response //
											if (Error_feedback_buzzer_NR2A == 1) {

												do{
													NiFpga_MergeStatus(&status, NiFpga_ReadU32(session, NiFpga_discriminationFPGA_IndicatorU32_data_main, &data_main));

													if ((data_main - choice1_time) <= window_NR2A * 1000) {

														NiFpga_MergeStatus(&status, NiFpga_ReadU32(session, NiFpga_discriminationFPGA_IndicatorU32_data_right_falling, &data_right_falling));

														if (data_right_falling > counter_value_right_falling) {
															NiFpga_MergeStatus(&status, NiFpga_ReadU32(session, NiFpga_discriminationFPGA_IndicatorU32_data_main, &data_main));
															NR2A_feedback_on_time = data_main;
															NR2A = 1;

															if (laser_switch[trial] == 1){
																if (laser_delivery_epoch == 4){
																	NiFpga_MergeStatus(&status, NiFpga_WriteBool(session, NiFpga_discriminationFPGA_ControlBool_Laser, ON)); //2018015
																}
															}

															error_feedback();
															NR2A_WindowExitflag = true;
															iti = iti_error_NR2A;
														}
													}

													else if ((data_main - choice1_time) > window_NR2A * 1000) {
														NR2A = 0;
														NR2A_WindowExitflag = true;
													}

												} while (NR2A_WindowExitflag == false);
											}
											// 2020-02-20 Add error feedback buzzer for NR2A response //

											Serial_Response_Completed_Flag = true;
											break;

										case 2:

											NiFpga_MergeStatus(&status, NiFpga_ReadU32(session, NiFpga_discriminationFPGA_IndicatorU32_data_middle_falling, &data_middle_falling));
											counter_value_middle_falling = data_middle_falling;

											if (LED_off_timing == 0) {
												NiFpga_MergeStatus(&status, NiFpga_WriteBool(session, NiFpga_discriminationFPGA_ControlBool_LED_Middle, false));
											}

											if (Reward_delivery_switch == 1){

												if (random_delay_reward_switch == 1){
													random_delay_reward = rnd() % delay_reward_range;
													Sleep(random_delay_reward);

												}

												NiFpga_MergeStatus(&status, NiFpga_ReadU32(session, NiFpga_discriminationFPGA_IndicatorU32_data_main, &data_main));
												emv_on_time1 = data_main;

												NiFpga_MergeStatus(&status, NiFpga_WriteBool(session, NiFpga_discriminationFPGA_ControlBool_Catch_Trial, ON));
												NiFpga_MergeStatus(&status, NiFpga_WriteBool(session, NiFpga_discriminationFPGA_ControlBool_EMV, ON));

											}

											do{ // 11th layer
												NiFpga_MergeStatus(&status, NiFpga_ReadU32(session, NiFpga_discriminationFPGA_IndicatorU32_data_middle_falling, &data_middle_falling));
												NiFpga_MergeStatus(&status, NiFpga_ReadU32(session, NiFpga_discriminationFPGA_IndicatorU32_data_left_falling, &data_left_falling));
												NiFpga_MergeStatus(&status, NiFpga_ReadU32(session, NiFpga_discriminationFPGA_IndicatorU32_data_right_falling, &data_right_falling));

												if (Repechage_choice2_switch != 0) {
													if (data_right_falling > counter_value_right_falling) { // Correctly go Left then Right. // 12th layer
														NiFpga_MergeStatus(&status, NiFpga_ReadU32(session, NiFpga_discriminationFPGA_IndicatorU32_data_main, &data_main));
														choice2_time = data_main;

														if (laser_switch[trial] == 1){
															if (laser_delivery_epoch == 2){
																NiFpga_MergeStatus(&status, NiFpga_WriteBool(session, NiFpga_discriminationFPGA_ControlBool_Laser, ON)); //2018015
															}
														}

														if (LED_off_timing == 1) {
															NiFpga_MergeStatus(&status, NiFpga_WriteBool(session, NiFpga_discriminationFPGA_ControlBool_LED_Middle, false));
														}

														NiFpga_MergeStatus(&status, NiFpga_WriteBool(session, NiFpga_discriminationFPGA_ControlBool_LED_Right, false));

														NiFpga_MergeStatus(&status, NiFpga_WriteBool(session, NiFpga_discriminationFPGA_ControlBool_Catch_Trial, OFF));

														if (random_delay_reward_switch == 1) {
															random_delay_reward = rnd() % delay_reward_range;
															Sleep(random_delay_reward);
														}

														NiFpga_MergeStatus(&status, NiFpga_ReadU32(session, NiFpga_discriminationFPGA_IndicatorU32_data_main, &data_main));
														emv_on_time2 = data_main;
														NiFpga_MergeStatus(&status, NiFpga_WriteBool(session, NiFpga_discriminationFPGA_ControlBool_EMV, ON));

														performance_choice2 = 1;
														performance = 1;
														error_choice = OFF;

														iti = iti_correct;

														++trial_glr_lr;

														Serial_Response_Completed_Flag = true;
													} // // 12th layer
												}

												if (Repechage_choice2_switch == 0) {
													if (data_middle_falling > counter_value_middle_falling) { // Incorrectly go Left then Middle. // 12th layer
														NiFpga_MergeStatus(&status, NiFpga_ReadU32(session, NiFpga_discriminationFPGA_IndicatorU32_data_main, &data_main));
														choice2_time = data_main;

														if (laser_switch[trial] == 1){
															if (laser_delivery_epoch == 3){
																NiFpga_MergeStatus(&status, NiFpga_WriteBool(session, NiFpga_discriminationFPGA_ControlBool_Laser, ON)); //2018015
															}
														}

														if (Error_feedback_buzzer == 1) {
															error_feedback_on_time = data_main;
															error_feedback();
														}

														NiFpga_MergeStatus(&status, NiFpga_WriteBool(session, NiFpga_discriminationFPGA_ControlBool_LED_Middle, false));
														NiFpga_MergeStatus(&status, NiFpga_WriteBool(session, NiFpga_discriminationFPGA_ControlBool_LED_Left, false));
														NiFpga_MergeStatus(&status, NiFpga_WriteBool(session, NiFpga_discriminationFPGA_ControlBool_LED_Right, false));

														performance_choice2 = 0;
														performance = 0;

														error_choice = ON;

														iti = iti_error;

														++trial_glr_lc;
														Serial_Response_Completed_Flag = true;
													}

													else if (data_right_falling > counter_value_right_falling) { // Correctly go Left then Right. // 12th layer
														NiFpga_MergeStatus(&status, NiFpga_ReadU32(session, NiFpga_discriminationFPGA_IndicatorU32_data_main, &data_main));
														choice2_time = data_main;

														if (laser_switch[trial] == 1){
															if (laser_delivery_epoch == 2){
																NiFpga_MergeStatus(&status, NiFpga_WriteBool(session, NiFpga_discriminationFPGA_ControlBool_Laser, ON)); //2018015
															}
														}

														if (LED_off_timing == 1) {
															NiFpga_MergeStatus(&status, NiFpga_WriteBool(session, NiFpga_discriminationFPGA_ControlBool_LED_Middle, false));
														}

														NiFpga_MergeStatus(&status, NiFpga_WriteBool(session, NiFpga_discriminationFPGA_ControlBool_LED_Right, false));

														NiFpga_MergeStatus(&status, NiFpga_WriteBool(session, NiFpga_discriminationFPGA_ControlBool_Catch_Trial, OFF));

														if (random_delay_reward_switch == 1) {
															random_delay_reward = rnd() % delay_reward_range;
															Sleep(random_delay_reward);
														}

														NiFpga_MergeStatus(&status, NiFpga_ReadU32(session, NiFpga_discriminationFPGA_IndicatorU32_data_main, &data_main));
														emv_on_time2 = data_main;
														NiFpga_MergeStatus(&status, NiFpga_WriteBool(session, NiFpga_discriminationFPGA_ControlBool_EMV, ON));

														performance_choice2 = 1;
														performance = 1;
														error_choice = OFF;

														iti = iti_correct;

														++trial_glr_lr;

														Serial_Response_Completed_Flag = true;
													} // // 12th layer

												}

											} while (Serial_Response_Completed_Flag == false);// 11th layer
											break;

										case 3:
											NiFpga_MergeStatus(&status, NiFpga_ReadU32(session, NiFpga_discriminationFPGA_IndicatorU32_data_middle_falling, &data_middle_falling));
											counter_value_middle_falling = data_middle_falling;

											if (LED_off_timing == 0){
												NiFpga_MergeStatus(&status, NiFpga_WriteBool(session, NiFpga_discriminationFPGA_ControlBool_LED_Middle, false));
											}

											if (Reward_delivery_switch == 1){

												if (random_delay_reward_switch == 1){
													random_delay_reward = rnd() % delay_reward_range;
													Sleep(random_delay_reward);

												}

												NiFpga_MergeStatus(&status, NiFpga_ReadU32(session, NiFpga_discriminationFPGA_IndicatorU32_data_main, &data_main));
												emv_on_time1 = data_main;

												NiFpga_MergeStatus(&status, NiFpga_WriteBool(session, NiFpga_discriminationFPGA_ControlBool_Catch_Trial, ON));
												NiFpga_MergeStatus(&status, NiFpga_WriteBool(session, NiFpga_discriminationFPGA_ControlBool_EMV, ON));

											}

											do{ // 11th layer
												NiFpga_MergeStatus(&status, NiFpga_ReadU32(session, NiFpga_discriminationFPGA_IndicatorU32_data_middle_falling, &data_middle_falling));
												NiFpga_MergeStatus(&status, NiFpga_ReadU32(session, NiFpga_discriminationFPGA_IndicatorU32_data_left_falling, &data_left_falling));
												NiFpga_MergeStatus(&status, NiFpga_ReadU32(session, NiFpga_discriminationFPGA_IndicatorU32_data_right_falling, &data_right_falling));

												if (data_right_falling > counter_value_right_falling){ // Correctly go Left then Right. // 12th layer
													NiFpga_MergeStatus(&status, NiFpga_ReadU32(session, NiFpga_discriminationFPGA_IndicatorU32_data_main, &data_main));
													choice2_time = data_main;
													performance_choice2 = 1;

													if (Reward_delivery_switch == 1){

														if (random_delay_reward_switch == 1){
															random_delay_reward = rnd() % delay_reward_range;
															Sleep(random_delay_reward);

														}

														NiFpga_MergeStatus(&status, NiFpga_ReadU32(session, NiFpga_discriminationFPGA_IndicatorU32_data_main, &data_main));
														emv_on_time2 = data_main;

														NiFpga_MergeStatus(&status, NiFpga_WriteBool(session, NiFpga_discriminationFPGA_ControlBool_Catch_Trial, ON));
														NiFpga_MergeStatus(&status, NiFpga_WriteBool(session, NiFpga_discriminationFPGA_ControlBool_EMV, ON));

													}

													NiFpga_MergeStatus(&status, NiFpga_ReadU32(session, NiFpga_discriminationFPGA_IndicatorU32_data_middle_falling, &data_middle_falling));
													NiFpga_MergeStatus(&status, NiFpga_ReadU32(session, NiFpga_discriminationFPGA_IndicatorU32_data_left_falling, &data_left_falling));
													NiFpga_MergeStatus(&status, NiFpga_ReadU32(session, NiFpga_discriminationFPGA_IndicatorU32_data_right_falling, &data_right_falling));
													counter_value_middle_falling = data_middle_falling;
													counter_value_left_falling = data_left_falling;
													counter_value_right_falling = data_right_falling;

													do{
														NiFpga_MergeStatus(&status, NiFpga_ReadU32(session, NiFpga_discriminationFPGA_IndicatorU32_data_middle_falling, &data_middle_falling));
														NiFpga_MergeStatus(&status, NiFpga_ReadU32(session, NiFpga_discriminationFPGA_IndicatorU32_data_left_falling, &data_left_falling));
														NiFpga_MergeStatus(&status, NiFpga_ReadU32(session, NiFpga_discriminationFPGA_IndicatorU32_data_right_falling, &data_right_falling));

														if (data_left_falling > counter_value_left_falling){ // Correctly go Left, Right and Left.
															NiFpga_MergeStatus(&status, NiFpga_ReadU32(session, NiFpga_discriminationFPGA_IndicatorU32_data_main, &data_main));
															choice3_time = data_main;

															if (LED_off_timing == 1) {
																NiFpga_MergeStatus(&status, NiFpga_WriteBool(session, NiFpga_discriminationFPGA_ControlBool_LED_Middle, false));
															}
															NiFpga_MergeStatus(&status, NiFpga_WriteBool(session, NiFpga_discriminationFPGA_ControlBool_LED_Right, false));

															NiFpga_MergeStatus(&status, NiFpga_WriteBool(session, NiFpga_discriminationFPGA_ControlBool_Catch_Trial, OFF));

															if (random_delay_reward_switch == 1){
																random_delay_reward = rnd() % delay_reward_range;
																Sleep(random_delay_reward);
															}

															NiFpga_MergeStatus(&status, NiFpga_ReadU32(session, NiFpga_discriminationFPGA_IndicatorU32_data_main, &data_main));
															emv_on_time3 = data_main;
															NiFpga_MergeStatus(&status, NiFpga_WriteBool(session, NiFpga_discriminationFPGA_ControlBool_EMV, ON));

															performance_choice3 = 1;
															performance = 1;
															error_choice = OFF;

															iti = iti_correct;
															++trial_glrl_lrl;

															Serial_Response_Completed_Flag = true;
														}

														if (Repechage_choice3_switch == 0){
															if (data_middle_falling > counter_value_middle_falling){ // Incorrectly go Left, Right and then Middle. // 12th layer
																NiFpga_MergeStatus(&status, NiFpga_ReadU32(session, NiFpga_discriminationFPGA_IndicatorU32_data_main, &data_main));
																choice3_time = data_main;

																if (Error_feedback_buzzer == 1){
																	error_feedback_on_time = data_main;
																	error_feedback();
																}

																NiFpga_MergeStatus(&status, NiFpga_WriteBool(session, NiFpga_discriminationFPGA_ControlBool_LED_Middle, false));
																NiFpga_MergeStatus(&status, NiFpga_WriteBool(session, NiFpga_discriminationFPGA_ControlBool_LED_Left, false));
																NiFpga_MergeStatus(&status, NiFpga_WriteBool(session, NiFpga_discriminationFPGA_ControlBool_LED_Right, false));

																performance_choice3 = 0;
																performance = 0;

																error_choice = ON;

																iti = iti_error;

																++trial_glrl_lrc;
																Serial_Response_Completed_Flag = true;
															}
														}
													} while (Serial_Response_Completed_Flag == false);


												} // // 12th layer

												if (Repechage_choice2_switch == 0){
													if (data_middle_falling > counter_value_middle_falling){ // Incorrectly go Left then Middle. // 12th layer
														NiFpga_MergeStatus(&status, NiFpga_ReadU32(session, NiFpga_discriminationFPGA_IndicatorU32_data_main, &data_main));
														choice2_time = data_main;

														if (Error_feedback_buzzer == 1){
															error_feedback_on_time = data_main;
															error_feedback();
														}

														NiFpga_MergeStatus(&status, NiFpga_WriteBool(session, NiFpga_discriminationFPGA_ControlBool_LED_Middle, false));
														NiFpga_MergeStatus(&status, NiFpga_WriteBool(session, NiFpga_discriminationFPGA_ControlBool_LED_Left, false));
														NiFpga_MergeStatus(&status, NiFpga_WriteBool(session, NiFpga_discriminationFPGA_ControlBool_LED_Right, false));

														performance_choice2 = 0;
														performance = 0;

														error_choice = ON;

														iti = iti_error;

														++trial_glrl_lc;
														Serial_Response_Completed_Flag = true;
													}
												}
											} while (Serial_Response_Completed_Flag == false);// 11th layer
											break;
										}

										break;

									case 1://10th layer -lever in left as first response although cue 1 delivered (i.e. grl-l).
										if (Error_feedback_buzzer == 1){
											error_feedback_on_time = data_main;
											error_feedback();
										}

										NiFpga_MergeStatus(&status, NiFpga_WriteBool(session, NiFpga_discriminationFPGA_ControlBool_LED_Middle, false));
										NiFpga_MergeStatus(&status, NiFpga_WriteBool(session, NiFpga_discriminationFPGA_ControlBool_LED_Left, false));
										NiFpga_MergeStatus(&status, NiFpga_WriteBool(session, NiFpga_discriminationFPGA_ControlBool_LED_Right, false));

										performance_choice1 = 0;
										performance_choice2 = -1;
										performance_choice3 = -1;

										performance = 0;
										error_choice = ON;

										iti = iti_error;

										switch (required_step){
										case 1:
											++trial_gr_l;
											break;
										case 2:
											++trial_grl_l;
											break;
										case 3:
											++trial_grlr_l;
											break;
										}
										break;
									}//10th layer -lever in left as first response although cue 0 delivered.

									NiFpga_MergeStatus(&status, NiFpga_ReadU32(session, NiFpga_discriminationFPGA_IndicatorU32_data_middle_falling, &data_middle_falling));
									NiFpga_MergeStatus(&status, NiFpga_ReadU32(session, NiFpga_discriminationFPGA_IndicatorU32_data_left_falling, &data_left_falling));
									NiFpga_MergeStatus(&status, NiFpga_ReadU32(session, NiFpga_discriminationFPGA_IndicatorU32_data_right_falling, &data_right_falling));
									counter_value_middle_falling = data_middle_falling;
									counter_value_left_falling = data_left_falling;
									counter_value_right_falling = data_right_falling;

									First_Went_to_Left_Flag = true;
								} // 9th layer
								/// End of First went to Left Port ///

								/// Start of First went to Right Port ///
								else if (data_right_falling > counter_value_right_falling){// 9th layer

									//printf("\rRight Port In: Count = %d", data_right);
									NiFpga_MergeStatus(&status, NiFpga_ReadU32(session, NiFpga_discriminationFPGA_IndicatorU32_data_main, &data_main));
									choice1_time = data_main;
									//response_time_choice1 = choice1_time - cue_start_time;
									//NiFpga_MergeStatus(&status, NiFpga_WriteBool(session, NiFpga_discriminationFPGA_ControlBool_EF_Flag, ON)); //timing of animal's right lever in 

									PlaySound(NULL, NULL, SND_ASYNC); //2016-01-06 added to stop tone in "Tone On Until Choice" mode

									if (laser_switch[trial] == 1){
										if (laser_delivery_epoch == 1){
											NiFpga_MergeStatus(&status, NiFpga_WriteBool(session, NiFpga_discriminationFPGA_ControlBool_Laser, ON)); //2018015
										}
									}

									switch (sound_identity)
									{

									case 0://10th layer -lever in right as first response although cue 0 delivered (i.e. glr_r).
										if (Error_feedback_buzzer == 1){
											error_feedback_on_time = data_main;
											error_feedback();
										}

										NiFpga_MergeStatus(&status, NiFpga_WriteBool(session, NiFpga_discriminationFPGA_ControlBool_LED_Middle, false));
										NiFpga_MergeStatus(&status, NiFpga_WriteBool(session, NiFpga_discriminationFPGA_ControlBool_LED_Left, false));
										NiFpga_MergeStatus(&status, NiFpga_WriteBool(session, NiFpga_discriminationFPGA_ControlBool_LED_Right, false));

										performance_choice1 = 0;
										performance_choice2 = -1;
										performance_choice3 = -1;

										performance = 0;
										error_choice = ON;

										iti = iti_error;

										switch (required_step){
										case 1:
											++trial_gl_r;
											break;
										case 2:
											++trial_glr_r;
											break;
										case 3:
											++trial_glrl_r;
											break;
										}
										break;

									case 1://10th layer -lever in right as first response after cue 1 delivered.

										NiFpga_MergeStatus(&status, NiFpga_ReadU32(session, NiFpga_discriminationFPGA_IndicatorU32_data_main, &data_main));

										counter_value_middle_falling = data_middle_falling;
										counter_value_left_falling = data_left_falling;
										counter_value_right_falling = data_right_falling;

										NiFpga_MergeStatus(&status, NiFpga_WriteBool(session, NiFpga_discriminationFPGA_ControlBool_LED_Right, false));
										//Sleep(lever_retract_delay1);

										performance_choice1 = 1;

										switch (required_step)
										{
										case 1:
											NiFpga_MergeStatus(&status, NiFpga_ReadU32(session, NiFpga_discriminationFPGA_IndicatorU32_data_main, &data_main));
											choice1_time = data_main;

											NiFpga_MergeStatus(&status, NiFpga_WriteBool(session, NiFpga_discriminationFPGA_ControlBool_LED_Middle, false));
											NiFpga_MergeStatus(&status, NiFpga_WriteBool(session, NiFpga_discriminationFPGA_ControlBool_LED_Right, false));

											NiFpga_MergeStatus(&status, NiFpga_WriteBool(session, NiFpga_discriminationFPGA_ControlBool_Catch_Trial, OFF));

											if (random_delay_reward_switch == 1){
												random_delay_reward = rnd() % delay_reward_range;
												Sleep(random_delay_reward);
											}

											NiFpga_MergeStatus(&status, NiFpga_ReadU32(session, NiFpga_discriminationFPGA_IndicatorU32_data_main, &data_main));
											emv_on_time1 = data_main;
											NiFpga_MergeStatus(&status, NiFpga_WriteBool(session, NiFpga_discriminationFPGA_ControlBool_EMV, ON));

											performance_choice1 = 1;
											performance = 1;
											error_choice = OFF;

											iti = iti_correct;

											++trial_gr_r;

											// 2020-02-20 Add error feedback buzzer for NR2A response //
											if (Error_feedback_buzzer_NR2A == 1) {

												do {
													NiFpga_MergeStatus(&status, NiFpga_ReadU32(session, NiFpga_discriminationFPGA_IndicatorU32_data_main, &data_main));

													if ((data_main - choice1_time) <= window_NR2A * 1000) {

														NiFpga_MergeStatus(&status, NiFpga_ReadU32(session, NiFpga_discriminationFPGA_IndicatorU32_data_left_falling, &data_left_falling));

														if (data_left_falling > counter_value_left_falling) {
															NiFpga_MergeStatus(&status, NiFpga_ReadU32(session, NiFpga_discriminationFPGA_IndicatorU32_data_main, &data_main));
															NR2A_feedback_on_time = data_main;
															NR2A = 1;

															if (laser_switch[trial] == 1){
																if (laser_delivery_epoch == 4){
																	NiFpga_MergeStatus(&status, NiFpga_WriteBool(session, NiFpga_discriminationFPGA_ControlBool_Laser, ON)); //2018015
																}
															}

															error_feedback();
															NR2A_WindowExitflag = true;
															iti = iti_error_NR2A;
														}
													}

													else if ((data_main - choice1_time) > window_NR2A * 1000) {
														NR2A = 0;
														NR2A_WindowExitflag = true;
													}

												} while (NR2A_WindowExitflag == false);
											}
											// 2020-02-20 Add error feedback buzzer for NR2A response //

											Serial_Response_Completed_Flag = true;
											break;

										case 2:
											NiFpga_MergeStatus(&status, NiFpga_ReadU32(session, NiFpga_discriminationFPGA_IndicatorU32_data_middle_falling, &data_middle_falling));
											counter_value_middle_falling = data_middle_falling;

											if (LED_off_timing == 0) {
												NiFpga_MergeStatus(&status, NiFpga_WriteBool(session, NiFpga_discriminationFPGA_ControlBool_LED_Middle, false));
											}

											if (Reward_delivery_switch == 1){

												if (random_delay_reward_switch == 1){
													random_delay_reward = rnd() % delay_reward_range;
													Sleep(random_delay_reward);

												}

												NiFpga_MergeStatus(&status, NiFpga_ReadU32(session, NiFpga_discriminationFPGA_IndicatorU32_data_main, &data_main));
												emv_on_time1 = data_main;

												NiFpga_MergeStatus(&status, NiFpga_WriteBool(session, NiFpga_discriminationFPGA_ControlBool_Catch_Trial, ON));
												NiFpga_MergeStatus(&status, NiFpga_WriteBool(session, NiFpga_discriminationFPGA_ControlBool_EMV, ON));

											}

											do{// 11th layer -waiting the 2nd response lever in 
												NiFpga_MergeStatus(&status, NiFpga_ReadU32(session, NiFpga_discriminationFPGA_IndicatorU32_data_middle_falling, &data_middle_falling));
												NiFpga_MergeStatus(&status, NiFpga_ReadU32(session, NiFpga_discriminationFPGA_IndicatorU32_data_left_falling, &data_left_falling));
												NiFpga_MergeStatus(&status, NiFpga_ReadU32(session, NiFpga_discriminationFPGA_IndicatorU32_data_right_falling, &data_right_falling));

												if (Repechage_choice2_switch != 0) {
													if (data_left_falling > counter_value_left_falling) {// 12th layer -lever in left as 2nd response
														NiFpga_MergeStatus(&status, NiFpga_ReadU32(session, NiFpga_discriminationFPGA_IndicatorU32_data_main, &data_main));
														choice2_time = data_main;
														//response_time_choice2 = choice2_time - choice1_time;
														//NiFpga_MergeStatus(&status, NiFpga_WriteBool(session, NiFpga_discriminationFPGA_ControlBool_EF_Flag, ON)); //timing of animal's left lever in 

														//NiFpga_MergeStatus(&status, NiFpga_ReadU32(session, NiFpga_discriminationFPGA_IndicatorU32_data_main, &data_main));
														//choice_sound2_time = data_main;

														if (laser_switch[trial] == 1){
															if (laser_delivery_epoch == 2){
																NiFpga_MergeStatus(&status, NiFpga_WriteBool(session, NiFpga_discriminationFPGA_ControlBool_Laser, ON)); //2018015
															}
														}

														if (LED_off_timing == 1) {
															NiFpga_MergeStatus(&status, NiFpga_WriteBool(session, NiFpga_discriminationFPGA_ControlBool_LED_Middle, false));
														}

														NiFpga_MergeStatus(&status, NiFpga_WriteBool(session, NiFpga_discriminationFPGA_ControlBool_LED_Left, false));
														//NiFpga_MergeStatus(&status, NiFpga_WriteBool(session, NiFpga_discriminationFPGA_ControlBool_LED_Right, false));

														NiFpga_MergeStatus(&status, NiFpga_WriteBool(session, NiFpga_discriminationFPGA_ControlBool_Catch_Trial, OFF));

														if (random_delay_reward_switch == 1) {
															random_delay_reward = rnd() % delay_reward_range;
															Sleep(random_delay_reward);
														}

														NiFpga_MergeStatus(&status, NiFpga_ReadU32(session, NiFpga_discriminationFPGA_IndicatorU32_data_main, &data_main));
														emv_on_time2 = data_main;
														NiFpga_MergeStatus(&status, NiFpga_WriteBool(session, NiFpga_discriminationFPGA_ControlBool_EMV, ON));

														performance_choice2 = 1;
														performance = 1;
														error_choice = OFF;

														//lever_retract_delay2 = lever_retract_delay_correct;
														iti = iti_correct;

														++trial_grl_rl;

														Serial_Response_Completed_Flag = true;
													}// 12th layer
												}

												if (Repechage_choice2_switch == 0) {
													if (data_middle_falling > counter_value_middle_falling) { // Incorrectly go Right then Middle. // 12th layer
														NiFpga_MergeStatus(&status, NiFpga_ReadU32(session, NiFpga_discriminationFPGA_IndicatorU32_data_main, &data_main));
														choice2_time = data_main;

														if (laser_switch[trial] == 1){
															if (laser_delivery_epoch == 3){
																NiFpga_MergeStatus(&status, NiFpga_WriteBool(session, NiFpga_discriminationFPGA_ControlBool_Laser, ON)); //2018015
															}
														}

														if (Error_feedback_buzzer == 1) {
															error_feedback_on_time = data_main;
															error_feedback();
														}

														NiFpga_MergeStatus(&status, NiFpga_WriteBool(session, NiFpga_discriminationFPGA_ControlBool_LED_Middle, false));
														NiFpga_MergeStatus(&status, NiFpga_WriteBool(session, NiFpga_discriminationFPGA_ControlBool_LED_Left, false));
														NiFpga_MergeStatus(&status, NiFpga_WriteBool(session, NiFpga_discriminationFPGA_ControlBool_LED_Right, false));

														performance_choice2 = 0;
														performance = 0;

														error_choice = ON;

														iti = iti_error;

														++trial_grl_rc;
														Serial_Response_Completed_Flag = true;
													}

													else if (data_left_falling > counter_value_left_falling) {// 12th layer -lever in left as 2nd response
														NiFpga_MergeStatus(&status, NiFpga_ReadU32(session, NiFpga_discriminationFPGA_IndicatorU32_data_main, &data_main));
														choice2_time = data_main;
														//response_time_choice2 = choice2_time - choice1_time;
														//NiFpga_MergeStatus(&status, NiFpga_WriteBool(session, NiFpga_discriminationFPGA_ControlBool_EF_Flag, ON)); //timing of animal's left lever in 

														//NiFpga_MergeStatus(&status, NiFpga_ReadU32(session, NiFpga_discriminationFPGA_IndicatorU32_data_main, &data_main));
														//choice_sound2_time = data_main;

														if (laser_switch[trial] == 1){
															if (laser_delivery_epoch == 2){
																NiFpga_MergeStatus(&status, NiFpga_WriteBool(session, NiFpga_discriminationFPGA_ControlBool_Laser, ON)); //2018015
															}
														}

														if (LED_off_timing == 1) {
															NiFpga_MergeStatus(&status, NiFpga_WriteBool(session, NiFpga_discriminationFPGA_ControlBool_LED_Middle, false));
														}

														NiFpga_MergeStatus(&status, NiFpga_WriteBool(session, NiFpga_discriminationFPGA_ControlBool_LED_Left, false));
														//NiFpga_MergeStatus(&status, NiFpga_WriteBool(session, NiFpga_discriminationFPGA_ControlBool_LED_Right, false));

														NiFpga_MergeStatus(&status, NiFpga_WriteBool(session, NiFpga_discriminationFPGA_ControlBool_Catch_Trial, OFF));

														if (random_delay_reward_switch == 1) {
															random_delay_reward = rnd() % delay_reward_range;
															Sleep(random_delay_reward);
														}

														NiFpga_MergeStatus(&status, NiFpga_ReadU32(session, NiFpga_discriminationFPGA_IndicatorU32_data_main, &data_main));
														emv_on_time2 = data_main;
														NiFpga_MergeStatus(&status, NiFpga_WriteBool(session, NiFpga_discriminationFPGA_ControlBool_EMV, ON));

														performance_choice2 = 1;
														performance = 1;
														error_choice = OFF;

														//lever_retract_delay2 = lever_retract_delay_correct;
														iti = iti_correct;

														++trial_grl_rl;

														Serial_Response_Completed_Flag = true;
													}// 12th layer
												}

											} while (Serial_Response_Completed_Flag == false);// 11th layer
											break;

										case 3:
											NiFpga_MergeStatus(&status, NiFpga_ReadU32(session, NiFpga_discriminationFPGA_IndicatorU32_data_middle_falling, &data_middle_falling));
											counter_value_middle_falling = data_middle_falling;

											if (LED_off_timing == 0) {
												NiFpga_MergeStatus(&status, NiFpga_WriteBool(session, NiFpga_discriminationFPGA_ControlBool_LED_Middle, false));
											}

											if (Reward_delivery_switch == 1){

												if (random_delay_reward_switch == 1){
													random_delay_reward = rnd() % delay_reward_range;
													Sleep(random_delay_reward);

												}

												NiFpga_MergeStatus(&status, NiFpga_ReadU32(session, NiFpga_discriminationFPGA_IndicatorU32_data_main, &data_main));
												emv_on_time1 = data_main;

												NiFpga_MergeStatus(&status, NiFpga_WriteBool(session, NiFpga_discriminationFPGA_ControlBool_Catch_Trial, ON));
												NiFpga_MergeStatus(&status, NiFpga_WriteBool(session, NiFpga_discriminationFPGA_ControlBool_EMV, ON));

											}

											do{// 11th layer -waiting the 2nd response lever in 
												NiFpga_MergeStatus(&status, NiFpga_ReadU32(session, NiFpga_discriminationFPGA_IndicatorU32_data_middle_falling, &data_middle_falling));
												NiFpga_MergeStatus(&status, NiFpga_ReadU32(session, NiFpga_discriminationFPGA_IndicatorU32_data_left_falling, &data_left_falling));
												NiFpga_MergeStatus(&status, NiFpga_ReadU32(session, NiFpga_discriminationFPGA_IndicatorU32_data_right_falling, &data_right_falling));

												if (data_left_falling > counter_value_left_falling){// 12th layer -lever in left as 2nd response
													NiFpga_MergeStatus(&status, NiFpga_ReadU32(session, NiFpga_discriminationFPGA_IndicatorU32_data_main, &data_main));
													choice2_time = data_main;
													performance_choice2 = 1;

													if (Reward_delivery_switch == 1){

														if (random_delay_reward_switch == 1){
															random_delay_reward = rnd() % delay_reward_range;
															Sleep(random_delay_reward);

														}

														NiFpga_MergeStatus(&status, NiFpga_ReadU32(session, NiFpga_discriminationFPGA_IndicatorU32_data_main, &data_main));
														emv_on_time2 = data_main;

														NiFpga_MergeStatus(&status, NiFpga_WriteBool(session, NiFpga_discriminationFPGA_ControlBool_Catch_Trial, ON));
														NiFpga_MergeStatus(&status, NiFpga_WriteBool(session, NiFpga_discriminationFPGA_ControlBool_EMV, ON));

													}

													NiFpga_MergeStatus(&status, NiFpga_ReadU32(session, NiFpga_discriminationFPGA_IndicatorU32_data_middle_falling, &data_middle_falling));
													NiFpga_MergeStatus(&status, NiFpga_ReadU32(session, NiFpga_discriminationFPGA_IndicatorU32_data_left_falling, &data_left_falling));
													NiFpga_MergeStatus(&status, NiFpga_ReadU32(session, NiFpga_discriminationFPGA_IndicatorU32_data_right_falling, &data_right_falling));
													counter_value_middle_falling = data_middle_falling;
													counter_value_left_falling = data_left_falling;
													counter_value_right_falling = data_right_falling;

													do{
														NiFpga_MergeStatus(&status, NiFpga_ReadU32(session, NiFpga_discriminationFPGA_IndicatorU32_data_middle_falling, &data_middle_falling));
														NiFpga_MergeStatus(&status, NiFpga_ReadU32(session, NiFpga_discriminationFPGA_IndicatorU32_data_left_falling, &data_left_falling));
														NiFpga_MergeStatus(&status, NiFpga_ReadU32(session, NiFpga_discriminationFPGA_IndicatorU32_data_right_falling, &data_right_falling));

														if (data_right_falling > counter_value_right_falling){

															NiFpga_MergeStatus(&status, NiFpga_ReadU32(session, NiFpga_discriminationFPGA_IndicatorU32_data_main, &data_main));
															choice3_time = data_main;

															if (LED_off_timing == 1) {
																NiFpga_MergeStatus(&status, NiFpga_WriteBool(session, NiFpga_discriminationFPGA_ControlBool_LED_Middle, false));
															}

															NiFpga_MergeStatus(&status, NiFpga_WriteBool(session, NiFpga_discriminationFPGA_ControlBool_LED_Left, false));
															//NiFpga_MergeStatus(&status, NiFpga_WriteBool(session, NiFpga_discriminationFPGA_ControlBool_LED_Right, false));

															NiFpga_MergeStatus(&status, NiFpga_WriteBool(session, NiFpga_discriminationFPGA_ControlBool_Catch_Trial, OFF));

															if (random_delay_reward_switch == 1){
																random_delay_reward = rnd() % delay_reward_range;
																Sleep(random_delay_reward);
															}

															NiFpga_MergeStatus(&status, NiFpga_ReadU32(session, NiFpga_discriminationFPGA_IndicatorU32_data_main, &data_main));
															emv_on_time3 = data_main;
															NiFpga_MergeStatus(&status, NiFpga_WriteBool(session, NiFpga_discriminationFPGA_ControlBool_EMV, ON));

															performance_choice3 = 1;
															performance = 1;
															error_choice = OFF;

															iti = iti_correct;
															++trial_grlr_rlr;

															Serial_Response_Completed_Flag = true;
														}

														if (Repechage_choice3_switch == 0){
															if (data_middle_falling > counter_value_middle_falling){ // Incorrectly go Right, Left and then Middle. // 12th layer
																NiFpga_MergeStatus(&status, NiFpga_ReadU32(session, NiFpga_discriminationFPGA_IndicatorU32_data_main, &data_main));
																choice3_time = data_main;

																if (Error_feedback_buzzer == 1){
																	error_feedback_on_time = data_main;
																	error_feedback();
																}

																NiFpga_MergeStatus(&status, NiFpga_WriteBool(session, NiFpga_discriminationFPGA_ControlBool_LED_Middle, false));
																NiFpga_MergeStatus(&status, NiFpga_WriteBool(session, NiFpga_discriminationFPGA_ControlBool_LED_Left, false));
																NiFpga_MergeStatus(&status, NiFpga_WriteBool(session, NiFpga_discriminationFPGA_ControlBool_LED_Right, false));

																performance_choice3 = 0;
																performance = 0;

																error_choice = ON;

																iti = iti_error;

																++trial_grlr_rlc;
																Serial_Response_Completed_Flag = true;
															}
														}
													} while (Serial_Response_Completed_Flag == false);

												}// 12th layer

												if (Repechage_choice2_switch == 0){
													if (data_middle_falling > counter_value_middle_falling){ // Incorrectly go Right then Middle. // 12th layer
														NiFpga_MergeStatus(&status, NiFpga_ReadU32(session, NiFpga_discriminationFPGA_IndicatorU32_data_main, &data_main));
														choice2_time = data_main;

														if (Error_feedback_buzzer == 1){
															error_feedback_on_time = data_main;
															error_feedback();
														}

														NiFpga_MergeStatus(&status, NiFpga_WriteBool(session, NiFpga_discriminationFPGA_ControlBool_LED_Middle, false));
														NiFpga_MergeStatus(&status, NiFpga_WriteBool(session, NiFpga_discriminationFPGA_ControlBool_LED_Left, false));
														NiFpga_MergeStatus(&status, NiFpga_WriteBool(session, NiFpga_discriminationFPGA_ControlBool_LED_Right, false));

														performance_choice2 = 0;
														performance = 0;

														error_choice = ON;

														iti = iti_error;

														++trial_grlr_rc;
														Serial_Response_Completed_Flag = true;
													}
												}

											} while (Serial_Response_Completed_Flag == false);// 11th layer
											break;
										}

										break;//10th laer
									}

									NiFpga_MergeStatus(&status, NiFpga_ReadU32(session, NiFpga_discriminationFPGA_IndicatorU32_data_middle_falling, &data_middle_falling));
									NiFpga_MergeStatus(&status, NiFpga_ReadU32(session, NiFpga_discriminationFPGA_IndicatorU32_data_left_falling, &data_left_falling));
									NiFpga_MergeStatus(&status, NiFpga_ReadU32(session, NiFpga_discriminationFPGA_IndicatorU32_data_right_falling, &data_right_falling));

									counter_value_middle_falling = data_middle_falling;
									counter_value_left_falling = data_left_falling;
									counter_value_right_falling = data_right_falling;

									First_Went_to_Right_Flag = true;

								}// 9th layer -first lever in right 
							} while ((First_Went_to_Left_Flag == false) && (First_Went_to_Right_Flag == false));// 8th layer

							NiFpga_MergeStatus(&status, NiFpga_WriteBool(session, NiFpga_discriminationFPGA_ControlBool_Counter_middle_ON, OFF));
							NiFpga_MergeStatus(&status, NiFpga_WriteBool(session, NiFpga_discriminationFPGA_ControlBool_Counter_middle_falling_ON, OFF)); //2018-03-15 added
							++trial;

							log << "" << endl;
							log << "Trial# " << trial << endl;
							log << "Sound: " << sound_identity << endl;
							log << "Step: " << required_step << endl;

							/*
							if (sound_identity == 0){
							if (required_step == 1){
							log << "TrialType: L" << endl;
							}
							else if (required_step == 2){
							log << "TrialType: LR" << endl;
							}
							else if (required_step == 3){
							log << "TrialType: LRL" << endl;
							}
							}

							else if (sound_identity == 1){
							if (required_step == 1){
							log << "TrialType: R" << endl;
							}
							else if (required_step == 2){
							log << "TrialType: RL" << endl;
							}
							else if (required_step == 3){
							log << "TrialType: RLR" << endl;
							}
							}

							else
							printf("\rErrorTrialType.\n");
							*/


							if (laser_experiment == 1){
								log << "Laser: " << laser_switch[trial - 1] << endl;
							}

							log << "Performance: " << performance << endl;
							log << "performance_choice1: " << performance_choice1 << endl;
							log << "performance_choice2: " << performance_choice2 << endl;
							log << "performance_choice3: " << performance_choice3 << endl;
							log << "NR2A: " << NR2A << endl;

							log << "Min: " << trial_start_time << endl;
							log << "Cue: " << cue_start_time << endl;
							log << "LED: " << led_on_time << endl;
							log << "Dly: " << delay_start_time << endl;
							log << "CH1: " << choice1_time << endl;

							switch (performance_choice1){
							case 0:
								log << "CH2: -1" << endl;
								log << "CH3: -1" << endl;
								log << "ERR: " << error_feedback_on_time << endl;
								break;
							case 1:
								switch (required_step){
								case 1:
									log << "EMV1: " << emv_on_time1 << endl;
									if (NR2A == 0) {
										log << "NR2AF: -1" << endl;
									}
									else if (NR2A == 1) {
										log << "NR2AF: " << NR2A_feedback_on_time << endl;
									}

									log << "CH2: -1" << endl;
									log << "CH3: -1" << endl;
									break;
								case 2:
									log << "EMV1: " << emv_on_time1 << endl;
									log << "CH2: " << choice2_time << endl;
									log << "CH3: -1" << endl;
									if (performance_choice2 == 0){
										log << "ERR: " << error_feedback_on_time << endl;
									}
									else if (performance_choice2 == 1){
										log << "EMV2: " << emv_on_time2 << endl;
									}
									break;
								case 3:
									log << "EMV1: " << emv_on_time1 << endl;
									log << "CH2: " << choice2_time << endl;
									if (performance_choice2 == 0){
										log << "CH3: -1" << endl;
										log << "ERR: " << error_feedback_on_time << endl;
									}
									else if (performance_choice2 == 1){
										log << "EMV2: " << emv_on_time2 << endl;
										log << "CH3: " << choice3_time << endl;
										if (performance_choice3 == 0){
											log << "ERR: " << error_feedback_on_time << endl;
										}
										else if (performance_choice3 == 1){
											log << "EMV3: " << emv_on_time3 << endl;
										}
									}
									break;
								}
								break;
							}

							//log << "ITI: " << iti_start_time << endl;

							//log << "RT_choice1: " << (choice1_time - cue_start_time) << endl;
							//log << "RT_choice2: " << (choice2_time - choice1_time) << endl;
							//log << "RT_choice3: " << (choice3_time - choice2_time) << endl;

							log << "gl-l: " << trial_gl_l << endl;
							log << "gl-r: " << trial_gl_r << endl;
							log << "gr-r: " << trial_gr_r << endl;
							log << "gr-l: " << trial_gr_l << endl;

							log << "glr-lr: " << trial_glr_lr << endl;
							log << "glr-lc: " << trial_glr_lc << endl;
							log << "glr-r: " << trial_glr_r << endl;
							log << "grl-rl: " << trial_grl_rl << endl;
							log << "grl-rc: " << trial_grl_rc << endl;
							log << "grl-l: " << trial_grl_l << endl;

							log << "glrl-lrl: " << trial_glrl_lrl << endl;
							log << "glrl-lrc: " << trial_glrl_lrc << endl;
							log << "glrl-lc: " << trial_glrl_lc << endl;
							log << "glrl-r: " << trial_glrl_r << endl;
							log << "grlr-rlr: " << trial_grlr_rlr << endl;
							log << "grlr-rlc: " << trial_grlr_rlc << endl;
							log << "grlr-rc: " << trial_grlr_rc << endl;
							log << "grlr-l: " << trial_grlr_l << endl;

							//printf("\r ---------------\n");
							printf("\r Trial Count = %d\n\n", trial);

							printf("\r -- Breakdown of Animal Responses (Single action) --\n\n");
							printf("\r [gl-l] = %d\n", trial_gl_l);
							printf("\r [gl-r]  = %d\n\n", trial_gl_r);
							printf("\r [gr-r] = %d\n", trial_gr_r);
							printf("\r [gr-l]  = %d\n\n", trial_gr_l);

							printf("\r -- Breakdown of Animal Responses (Two steps) --\n\n");
							printf("\r [glr-lr] = %d\n", trial_glr_lr);
							printf("\r [glr-lc] = %d\n", trial_glr_lc);
							printf("\r [glr-r]  = %d\n\n", trial_glr_r);
							printf("\r [grl-rl] = %d\n", trial_grl_rl);
							printf("\r [grl-rc] = %d\n", trial_grl_rc);
							printf("\r [grl-l]  = %d\n\n", trial_grl_l);

							/*printf("\r -- Breakdown of Animal Responses (Three steps) --\n\n");
							printf("\r [glrl-lrl] = %d\n", trial_glrl_lrl);
							printf("\r [glrl-lrc] = %d\n", trial_glrl_lrc);
							printf("\r [glrl-lc] = %d\n", trial_glrl_lc);
							printf("\r [glrl-r]  = %d\n\n", trial_glrl_r);
							printf("\r [grlr-rlr] = %d\n", trial_grlr_rlr);
							printf("\r [grlr-rlc] = %d\n", trial_grlr_rlc);
							printf("\r [grlr-rc] = %d\n", trial_grlr_rc);
							printf("\r [grlr-l]  = %d\n\n", trial_grlr_l);*/

							printf("\r --%% Correct (Single action) ----\n\n");
							if ((trial_gl_r + trial_gl_l + trial_gr_l + trial_gr_r) == 0){
								printf("\r (Total): NA\n");
							}
							if ((trial_gl_r + trial_gl_l + trial_gr_l + trial_gr_r) > 0){
								printf("\r (Total) = %d%%\n", (trial_gl_l + trial_gr_r) * 100 / (trial_gl_r + trial_gl_l + trial_gr_l + trial_gr_r));
							}

							if ((trial_gl_r + trial_gl_l) == 0){
								printf("\r (L): NA\n");
							}
							if ((trial_gl_r + trial_gl_l) > 0){
								printf("\r (L) = %d%%\n", trial_gl_l * 100 / (trial_gl_r + trial_gl_l));
							}
							if ((trial_gr_l + trial_gr_r) == 0){
								printf("\r (R): NA\n\n");
							}
							if ((trial_gr_l + trial_gr_r) > 0){
								printf("\r (R) = %d%%\n\n", trial_gr_r * 100 / (trial_gr_l + trial_gr_r));
							}

							printf("\r --%% Correct (Two steps) ----\n\n");

							if ((trial_glr_r + trial_glr_lr + trial_grl_l + trial_grl_rl + trial_glr_lc + trial_grl_rc) == 0){
								printf("\r (Total): NA\n");
							}
							if ((trial_glr_r + trial_glr_lr + trial_grl_l + trial_grl_rl + trial_glr_lc + trial_grl_rc) > 0){
								printf("\r (Total) = %d%%\n", (trial_glr_lr + trial_grl_rl) * 100 / (trial_glr_r + trial_glr_lr + trial_grl_l + trial_grl_rl + trial_glr_lc + trial_grl_rc));
							}

							if ((trial_glr_r + trial_glr_lr + trial_glr_lc) == 0){
								printf("\r (L-R): NA\n");
							}
							if ((trial_glr_r + trial_glr_lr + trial_glr_lc) > 0){
								printf("\r (L-R) = %d%%\n", trial_glr_lr * 100 / (trial_glr_r + trial_glr_lr + trial_glr_lc));
							}
							if ((trial_grl_l + trial_grl_rl + trial_grl_rc) == 0){
								printf("\r (R-L): NA\n\n");
							}
							if ((trial_grl_l + trial_grl_rl + trial_grl_rc) > 0){
								printf("\r (R-L) = %d%%\n\n", trial_grl_rl * 100 / (trial_grl_l + trial_grl_rl + trial_grl_rc));
							}

							/*printf("\r --%% Correct (Three steps) ----\n\n");

							if ((trial_glrl_r + trial_glrl_lrl + trial_grlr_l + trial_grlr_rlr + trial_glrl_lrc + trial_glrl_lc + trial_grlr_rlc + trial_grlr_rc) == 0){
							printf("\r (Total): NA\n");
							}
							if ((trial_glrl_r + trial_glrl_lrl + trial_grlr_l + trial_grlr_rlr + trial_glrl_lrc + trial_glrl_lc + trial_grlr_rlc + trial_grlr_rc) > 0){
							printf("\r (Total) = %d%%\n", (trial_glrl_lrl + trial_grlr_rlr) * 100 / (trial_glrl_r + trial_glrl_lrl + trial_grlr_l + trial_grlr_rlr + trial_glrl_lrc + trial_glrl_lc + trial_grlr_rlc + trial_grlr_rc));
							}

							if ((trial_glrl_r + trial_glrl_lrl + trial_glrl_lrc + trial_glrl_lc) == 0){
							printf("\r (L-R-L): NA\n");
							}
							if ((trial_glrl_r + trial_glrl_lrl + trial_glrl_lrc + trial_glrl_lc) > 0){
							printf("\r (L-R-L) = %d%%\n", trial_glrl_lrl * 100 / (trial_glrl_r + trial_glrl_lrl + trial_glrl_lrc + trial_glrl_lc));
							}
							if ((trial_grlr_l + trial_grlr_rlr + trial_grlr_rlc + trial_grlr_rc) == 0){
							printf("\r (R-L-R): NA\n\n");
							}
							if ((trial_grlr_l + trial_grlr_rlr + trial_grlr_rlc + trial_grlr_rc) > 0){
							printf("\r (R-L-R) = %d%%\n\n", trial_grlr_rlr * 100 / (trial_grlr_l + trial_grlr_rlr + trial_grlr_rlc + trial_grlr_rc));
							}*/

							printf("\n\r -------------------------------------\n");

							//printf("\r Response Time (0.1 ms)\n\n", trial);
							//printf("\r  Choice1: %d\n\n", response_time_choice1);
							//printf("\r  Choice2: %d\n\n", response_time_choice2);
							//printf("\r --Response Time [Median (0.1ms)]----\n\n");

							//NiFpga_MergeStatus(&status, NiFpga_WriteBool(session, NiFpga_discriminationFPGA_ControlBool_EF_Flag, OFF));
							NiFpga_MergeStatus(&status, NiFpga_WriteBool(session, NiFpga_discriminationFPGA_ControlBool_EMV, OFF));

							//Sleep(lever_retract_delay2);							
							NiFpga_MergeStatus(&status, NiFpga_WriteBool(session, NiFpga_discriminationFPGA_ControlBool_Lever_Left, OFF));
							NiFpga_MergeStatus(&status, NiFpga_WriteBool(session, NiFpga_discriminationFPGA_ControlBool_Lever_Right, OFF));

						} //7th layer // fixatioin break or no.

						NiFpga_MergeStatus(&status, NiFpga_ReadU32(session, NiFpga_discriminationFPGA_IndicatorU32_data_middle_falling, &data_middle_falling));
						counter_value_middle_falling = data_middle_falling;
						NiFpga_MergeStatus(&status, NiFpga_ReadU32(session, NiFpga_discriminationFPGA_IndicatorU32_data_left_falling, &data_left_falling));
						counter_value_left_falling = data_left_falling;
						NiFpga_MergeStatus(&status, NiFpga_ReadU32(session, NiFpga_discriminationFPGA_IndicatorU32_data_right_falling, &data_right_falling));
						counter_value_right_falling = data_right_falling;

						NiFpga_MergeStatus(&status, NiFpga_ReadU32(session, NiFpga_discriminationFPGA_IndicatorU32_data_main, &data_main));
						iti_start_time = data_main;
						//NiFpga_MergeStatus(&status, NiFpga_WriteBool(session, NiFpga_discriminationFPGA_ControlBool_EF_Flag, ON)); //timing of ITI start

						log << "ITI: " << iti_start_time << endl;
						//printf("\n\r iti_start_time = %d\n", iti_start_time);

						//Sleep(iti);

						//NiFpga_MergeStatus(&status, NiFpga_WriteBool(session, NiFpga_discriminationFPGA_ControlBool_LED_Center, true));
						//NiFpga_MergeStatus(&status, NiFpga_WriteBool(session, NiFpga_discriminationFPGA_ControlBool_EF_Flag, ON)); // timing of LED ON after ITI completes.

						TrialExitflag = true;

					}// 6th layer // waiting center lever in

				} // 2015-09-08// 5th layer // Wait passing iti periiod

			} while (TrialExitflag == false);// 4th layer // Trial

			FixationExitFlag = false;
			MiddlePortExitflag = false;

			First_Went_to_Left_Flag = false;
			First_Went_to_Right_Flag = false;
			RepechageExitflag = false;
			Serial_Response_Completed_Flag = false;
			TrialExitflag = false;
			NR2A_WindowExitflag = false;

			trial_ready_counter = 0x00000000;
			random_delay_reward = 0x00000000;
			trial_start_time = 0x00000000;
			led_on_time = 0x00000000;
			cue_start_time = 0x00000000;
			delay_start_time = 0x00000000;
			choice1_time = 0x00000000;
			choice2_time = 0x00000000;
			choice3_time = 0x00000000;
			emv_on_time1 = 0x00000000;
			emv_on_time2 = 0x00000000;
			emv_on_time3 = 0x00000000;
			error_feedback_on_time = 0x00000000;
			NR2A_feedback_on_time = 0x00000000;
			response_time_choice1 = 0x00000000;
			response_time_choice2 = 0x00000000;
			response_time_choice3 = 0x00000000;

		} while (Exitflag == false); // 3rd layer

		/* close the session now that we're done */
		printf("Closing the session...\n");
		NiFpga_MergeStatus(&status, NiFpga_Close(session, 0));

		/* must be called after all other calls */
		printf("Finalizing...\n");
		NiFpga_MergeStatus(&status, NiFpga_Finalize());

		log.close();

		/* check if anything went wrong */
		if (NiFpga_IsError(status))
		{
			printf("Error %d!\n", status);
			printf("Press <Enter> to quit...\n");
			getchar();
		}
		return status;

	}// 2nd layer

}// 1st layer