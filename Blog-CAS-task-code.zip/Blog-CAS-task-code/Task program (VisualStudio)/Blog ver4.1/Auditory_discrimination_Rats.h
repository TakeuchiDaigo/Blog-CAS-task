/******************************************************/
/*                                                    */
/* Module   : Auditory_discrimination.h		      */ 
/* Purpose  : function prototype		      */
/* Author   : DAigo Takeuchi			      */
/* Create   : 2013				      */
/* 						      */
/******************************************************/

#define QUITID         0
#define HARDWAREID     1
#define OPERANTID     10
#define OPERANT1ID    11
#define OPERANT2ID    12
#define DISCID	      20
#define DISC1ID	      21
#define DISC2ID       22
#define DISC3ID       23
#define TEMPID	      30
//#define STOPTASKID   100   

/*---------------newly created-----------------------------*/
typedef __int32 int32_t;
typedef unsigned __int32 uint32_t;

/*---------------menu.cpp-----------------------------*/

void begin(void);
void initiate(void);
int  task_menu(void);
void para_menu(void);
void prepare(void);

/*---------------blog01.cpp--------------------------*/

int  (*get_task(BYTE *))();

/*---------------blog02.cpp---------------------------*/

int  	    block_start( int );
//int         mallocall(void);

/*---------------blog03.cpp---------------------------*/

//void   event_timer_start(void);
//void   logon(void);
//void   logoff(void);

/*---------------auditory_disc.cpp---------------------------*/
void disc_para(void);
void temp_para(void);

/// FUnction declaration ///

static int blog(void);

std::string FormatTime(const time_t time);

std::random_device rnd;

using std::cin;
using std::cout;
using std::endl;

//int32 CVICALLBACK EveryNCallback(TaskHandle taskHandle, int32 everyNsamplesEventType, uInt32 nSamples, void *callbackData);
//int32 CVICALLBACK DoneCallback(TaskHandle taskHandle, int32 status, void *callbackData);

static int which_sound(void);
static int make_sound(void);
static int which_trial_type(void);

static int go_signal_on_cont(TCHAR	*soundfile);
static int go_signal_on_fixed(TCHAR	*soundfile);

static int error_feedback(void);
//static int load_wave_file(char *fname);

static int sort(uint32_t[], int);
static int median(uint32_t[], int);

static int variable_delay(uint32_t, uint32_t);

//////////////////////////////////////////////////////////////////////
static void disc_para()
{
	printf(" Hon-den. \n");
	printf("\n");
}

static void temp_para()
{
	printf(" Hon-den. \n");
	printf("\n");
}

static int which_sound()
{
	int	sound_identity;
	int     i;
 
	srand((unsigned)time( NULL ));
	i = rand() % 2;

	if (i <1){
	sound_identity = 0;
	}
	if (i > 0){
	sound_identity = 1;
	}

	printf("\n\r Sound = %d\n", sound_identity);
	
	return sound_identity;
}

static int go_signal_on_cont(TCHAR	*soundfile)
{
	int32   error{};
	char    errBuff[2048] = { '\0' };

	PlaySound(soundfile, NULL, SND_ASYNC | SND_LOOP);
	//PlaySound(soundfile, NULL, SND_ASYNC);

	return 0;
}

static int go_signal_on_fixed(TCHAR	*soundfile)
{
	int32   error{};
	char    errBuff[2048] = { '\0' };

	//PlaySound(soundfile, NULL, SND_ASYNC | SND_LOOP);
	PlaySound(soundfile, NULL, SND_ASYNC);

	return 0;
}

static int error_feedback()
{

	int32   error{};
	char    errBuff[2048] = { '\0' };
	TCHAR	*soundfile = TEXT("error_feedback.wav");

	//led_switch(taskHandle, led_state);
	PlaySound(soundfile, NULL, SND_ASYNC);

	return 0;
}

static int median(uint32_t new_array[], int num){
	int i;
	if (num % 2 != 0){
		int temp = ((num + 1) / 2) - 1;
		i = new_array[temp];
	}
	else{
		i = (new_array[(num / 2) - 1] + new_array[num / 2]) / 2;
		//std::cout << new_array[(num / 2) - 1] << " and " << new_array[num / 2] << std::endl;
	}

	std::cout << i << std::endl;
	return i;
}

static int sort(uint32_t new_array[], int num){
	int mrt;

	for (int x = 0; x<num; x++){
		for (int y = 0; y<num - 1; y++){
			if (new_array[y]>new_array[y + 1]){
				uint32_t temp = new_array[y + 1];
				new_array[y + 1] = new_array[y];
				new_array[y] = temp;
			}
		}
	}
	//cout << "List: ";
	//for (int i = 0; i<num; i++){
	//	cout << new_array[i] << " ";
	//}
	//cout << "\n";
	mrt = median(new_array, num);
	return mrt;
}

std::string FormatTime(const time_t time)
{
	struct tm ts;
	char szBuffer[80] = "DD-MM-YY HH:MM:SS";

	errno_t err = localtime_s(&ts, &time);

	if (err)
	{
	}
	else
	{
		// Format the time
		strftime(szBuffer, sizeof(szBuffer), "%d-%b-%Y %X%p", &ts);
	}
	return szBuffer;
}

static int variable_delay(uint32_t delay_range, uint32_t	delay_mean)
{
	int	delay_time;
	int     i;

	srand((unsigned)time(NULL));
	i = rand() % (2*delay_range);

	delay_time = delay_mean - delay_range + i;

	printf("\n\r Delay_reward = %d\n", delay_time);

	return delay_time;
}