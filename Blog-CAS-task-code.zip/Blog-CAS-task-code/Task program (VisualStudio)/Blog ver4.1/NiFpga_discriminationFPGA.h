/*
 * Generated with the FPGA Interface C API Generator 15.0.0
 * for NI-RIO 15.0.0 or later.
 */

#ifndef __NiFpga_discriminationFPGA_h__
#define __NiFpga_discriminationFPGA_h__

#ifndef NiFpga_Version
   #define NiFpga_Version 1500
#endif

#include "NiFpga.h"

/**
 * The filename of the FPGA bitfile.
 *
 * This is a #define to allow for string literal concatenation. For example:
 *
 *    static const char* const Bitfile = "C:\\" NiFpga_discriminationFPGA_Bitfile;
 */
#define NiFpga_discriminationFPGA_Bitfile "NiFpga_discriminationFPGA.lvbitx"

/**
 * The signature of the FPGA bitfile.
 */
static const char* const NiFpga_discriminationFPGA_Signature = "D01EB1042DE412652F142312032A9A8B";

typedef enum
{
   NiFpga_discriminationFPGA_IndicatorU32_data_left = 0x30,
   NiFpga_discriminationFPGA_IndicatorU32_data_left_falling = 0x14,
   NiFpga_discriminationFPGA_IndicatorU32_data_main = 0x80,
   NiFpga_discriminationFPGA_IndicatorU32_data_middle = 0x2C,
   NiFpga_discriminationFPGA_IndicatorU32_data_middle_falling = 0x1C,
   NiFpga_discriminationFPGA_IndicatorU32_data_right = 0x78,
   NiFpga_discriminationFPGA_IndicatorU32_data_right_falling = 0x18,
} NiFpga_discriminationFPGA_IndicatorU32;

typedef enum
{
   NiFpga_discriminationFPGA_ControlBool_Catch_Trial = 0x26,
   NiFpga_discriminationFPGA_ControlBool_Counter_middle_ON = 0x36,
   NiFpga_discriminationFPGA_ControlBool_Counter_middle_falling_ON = 0x12,
   NiFpga_discriminationFPGA_ControlBool_EF_Flag = 0x3A,
   NiFpga_discriminationFPGA_ControlBool_EMV = 0x8E,
   NiFpga_discriminationFPGA_ControlBool_Enable_CLK = 0x86,
   NiFpga_discriminationFPGA_ControlBool_Enable_EMV = 0x8A,
   NiFpga_discriminationFPGA_ControlBool_Enable_Eventflag = 0x3E,
   NiFpga_discriminationFPGA_ControlBool_Enable_LED_Left = 0x7E,
   NiFpga_discriminationFPGA_ControlBool_Enable_LED_Middle = 0x5E,
   NiFpga_discriminationFPGA_ControlBool_Enable_LED_Right = 0x6E,
   NiFpga_discriminationFPGA_ControlBool_Enable_Laser = 0x42,
   NiFpga_discriminationFPGA_ControlBool_Enable_Lever_Left = 0x9A,
   NiFpga_discriminationFPGA_ControlBool_Enable_Lever_Middle = 0x62,
   NiFpga_discriminationFPGA_ControlBool_Enable_Lever_Right = 0x72,
   NiFpga_discriminationFPGA_ControlBool_LED_Left = 0x66,
   NiFpga_discriminationFPGA_ControlBool_LED_Middle = 0x5A,
   NiFpga_discriminationFPGA_ControlBool_LED_Right = 0x6A,
   NiFpga_discriminationFPGA_ControlBool_Laser = 0x2A,
   NiFpga_discriminationFPGA_ControlBool_Lever_Left = 0x4E,
   NiFpga_discriminationFPGA_ControlBool_Lever_Middle = 0x46,
   NiFpga_discriminationFPGA_ControlBool_Lever_Right = 0x76,
} NiFpga_discriminationFPGA_ControlBool;

typedef enum
{
   NiFpga_discriminationFPGA_ControlU32_EMV_open_duration = 0x94,
   NiFpga_discriminationFPGA_ControlU32_EMV_open_duration_catch = 0x20,
   NiFpga_discriminationFPGA_ControlU32_delay_left = 0x50,
   NiFpga_discriminationFPGA_ControlU32_delay_middle = 0x48,
   NiFpga_discriminationFPGA_ControlU32_delay_reward = 0x90,
   NiFpga_discriminationFPGA_ControlU32_delay_right = 0x54,
} NiFpga_discriminationFPGA_ControlU32;

#endif
