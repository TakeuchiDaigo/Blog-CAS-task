/*************************************************************************/
/*                                                                       */
/*	Module	: tasktbl.h                                              */
/*	Purpose	: Definitions of External Variables                      */
/*	Author	: Daigo Takeuchi                                         */
/*	Create	: 2013                                                   */
/*                                                                       */
/*************************************************************************/

/*	Definitions	*/

int  task_set;  	/* task set No */
int  exitflag = OFF;