
cue_tone
% error_feedback_sound
% chirp
% prompt

function cue_tone

duration = 0.30;%seconds
sR = 44100; % Hz
f = 8000; % Hz
sample = sR*duration;

t = 1:sample; % seconds
go_signal_2 = 0.25 * sin(2*pi*f*t/sR);

sound(go_signal_2, sR);
% %audiowrite([go_signal_2'; go_signal_2'], sR, 'C:\Users\daigo\Documents\MATLAB\work\work_mit\sound_file\go_signal_2.wav');
audiowrite('C:\Users\daigo\Documents\MATLAB\work\work_mit\sound_file\8khz_300ms_025.wav',[go_signal_2'], sR);
%wavwrite([go_signal_2'], sR, 'C:\Users\daigo\Documents\MATLAB\work\work_mit\sound_file\8khz_1500ms.wav');

end

%--------------------------------------------------------------------------
% error feedback: white noise, 500ms
function error_feedback_sound

len = 0.5;%seconds
sR = 44100;%Hz

% incorrectTone = 0.05 * 0.025 * rand(sR * len, 1);
incorrectTone = 0.5 * rand(sR * len, 1);
% figure; plot(incorrectTone, 'o:');
sound(incorrectTone, sR);
%size(incorrectTone)
wavwrite([incorrectTone; incorrectTone], sR, 'C:\Users\daigo\Documents\MATLAB\work\work_mit\sound_file\error_feedback.wav');

end

%%% --------------------------------------------------------------------------
% function correct_feedback_sound
% 
% duration = 0.5;%seconds
% sR = 44100; % Hz
% f = 4000; % Hz
% sample = sR*duration;
% 
% t = 1:sample; % seconds
% correctTone = 0.5 * sin(2*pi*f*t/sR);
% %size(correctTone)
% figure; plot(correctTone, 'o:');
% sound(correctTone, sR);
% wavwrite([correctTone'; correctTone'], sR, 'C:\Users\daigo\Documents\MATLAB\work\work_mit\sound_file\correct_feedback.wav');

%--------------------------------------------------------------------------
% function stop_sound
%
% duration = 0.02;%seconds
% sR = 44100; % Hz
% f = 8000; % Hz
% sample = sR*duration;
%
% t = 1:sample; % seconds
% stop_signal = 0.5 * sin(2*pi*f*t/sR);
%
% sound(stop_signal, sR);
% wavwrite([stop_signal'; stop_signal'], sR, 'C:\Users\daigo\Documents\MATLAB\work\work_mit\sound_file\stop_signal.wav');


% %--------------------------------------------------------------------------
% function chirp
%
% len = 0.75;%seconds
% sR = 60000;%samples/second
% mnF = 1500;%Hz
% mxF = 40000;%Hz
%
% chirpDomain = 1 : sR * len - len / sR;
% chirpDomain = chirpDomain / max(chirpDomain) * pi;% * 2
% f = mnF : (mxF - mnF) / length(chirpDomain) :  mxF - (mxF - mnF) / length(chirpDomain);
%
% % f(1:end) = f(end:-1:1);
% chirp = 0.05 * sin(f .* chirpDomain / (2 * pi));
% % figure; plot(chirp, 'o:');
% sound(chirp, sR);
%
% %--------------------------------------------------------------------------
% % correct: 10kHz, 200ms
% function prompt
%
% len = 0.2;%seconds
% sR = 44100;%samples/second
% f = 5000;%Hz
% domain = 1 : sR * len - len / sR;
% domain = domain / max(domain) * pi;
% correctTone = 0.1 * 0.05 * sin(f * domain);
%
% % figure; plot(correctTone, 'o:');
% sound(correctTone, sR);
% wavwrite([correctTone; correctTone], sR, 'C:\Users\daigo\Documents\MATLAB\work\work_mit\sound_file\promptTone.wav');
